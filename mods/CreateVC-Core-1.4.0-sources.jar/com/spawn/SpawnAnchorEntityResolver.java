package com.spawn;

import java.util.Comparator;
import java.util.Optional;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class SpawnAnchorEntityResolver {
    private static final double ROOT_SEARCH_HORIZONTAL_RADIUS = 12.0D;
    private static final double ROOT_SEARCH_VERTICAL_RADIUS = 10.0D;
    private static final Set<String> ROOT_ENTITY_TERMS = Set.of(
            "ship",
            "airship",
            "contraption",
            "vehicle",
            "physics",
            "bearing",
            "assembler");
    private static final Set<String> HELPER_ENTITY_TERMS = Set.of(
            "glue",
            "diagram",
            "pointer",
            "sensor",
            "gust",
            "beam");

    private SpawnAnchorEntityResolver() {
    }

    public static Entity normalize(Entity entity) {
        Entity rootVehicle = entity.getRootVehicle();
        if (rootVehicle != entity && isPreferredAnchor(rootVehicle)) {
            return rootVehicle;
        }

        if (isPreferredAnchor(entity) && !isLikelyHelperEntity(entity)) {
            return entity;
        }

        return findNearbyPreferredAnchor(entity).orElse(entity);
    }

    private static Optional<Entity> findNearbyPreferredAnchor(Entity entity) {
        AABB searchBox = entity.getBoundingBox().inflate(
                ROOT_SEARCH_HORIZONTAL_RADIUS,
                ROOT_SEARCH_VERTICAL_RADIUS,
                ROOT_SEARCH_HORIZONTAL_RADIUS);

        return entity.level()
                .getEntities(entity, searchBox, SpawnAnchorEntityResolver::isPreferredAnchor)
                .stream()
                .min(Comparator.comparingDouble(candidate -> anchorRootScore(entity, candidate)));
    }

    private static boolean isPreferredAnchor(Entity entity) {
        if (entity == null || !entity.isAlive() || entity instanceof Player) {
            return false;
        }

        if (EntityAnchorTransforms.supportsCustomTransform(entity) || SpawnCreateCompat.isCreateContraptionEntity(entity)) {
            return true;
        }

        ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (key == null) {
            return false;
        }

        String path = key.getPath();
        for (String term : ROOT_ENTITY_TERMS) {
            if (path.contains(term)) {
                return true;
            }
        }

        return !(entity instanceof LivingEntity) && key.getNamespace().contains("aeronautics");
    }

    private static boolean isLikelyHelperEntity(Entity entity) {
        ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (key == null) {
            return false;
        }

        String path = key.getPath();
        for (String term : HELPER_ENTITY_TERMS) {
            if (path.contains(term)) {
                return true;
            }
        }

        return !EntityAnchorTransforms.supportsCustomTransform(entity) && entity.getBoundingBox().getSize() < 6.0D;
    }

    private static double anchorRootScore(Entity source, Entity candidate) {
        AABB sourceBox = source.getBoundingBox();
        AABB candidateBox = candidate.getBoundingBox();
        Vec3 sourcePosition = source.position();
        Vec3 candidateCenter = candidateBox.getCenter();

        double score = sourcePosition.distanceToSqr(candidateCenter);
        score += Math.abs(candidateBox.maxY - sourceBox.minY) * 1.5D;

        if (source.getRootVehicle() == candidate) {
            score -= 64.0D;
        }

        if (candidateBox.intersects(sourceBox) || candidateBox.contains(sourcePosition)) {
            score -= 32.0D;
        }

        if (EntityAnchorTransforms.supportsCustomTransform(candidate)) {
            score -= 24.0D;
        }

        if (SpawnCreateCompat.isCreateContraptionEntity(candidate)) {
            score -= 16.0D;
        }

        score -= Math.min(candidateBox.getSize(), 48.0D);
        return score;
    }
}
