package com.spawn;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class EntityAnchorTransforms {
    private static final float CURRENT_TICK_PARTIAL = 1.0F;
    private static final Map<Class<?>, Optional<RotationAdapter>> ADAPTER_CACHE = new ConcurrentHashMap<>();
    private static final Set<String> LOGGED_ADAPTER_FAILURES = ConcurrentHashMap.newKeySet();

    private EntityAnchorTransforms() {
    }

    public static boolean supportsCustomTransform(Entity entity) {
        if (entity instanceof AbstractContraptionEntity) {
            return true;
        }

        if (entity instanceof ControlledContraptionEntity) {
            return true;
        }

        return resolveAdapter(entity).isPresent();
    }

    public static Vec3 toEntityLocal(Entity entity, Vec3 worldOffset) {
        if (entity instanceof AbstractContraptionEntity) {
            return worldOffset;
        }

        if (entity instanceof ControlledContraptionEntity controlledContraption) {
            return controlledContraption.reverseRotation(worldOffset, CURRENT_TICK_PARTIAL);
        }

        return resolveAdapter(entity)
                .flatMap(adapter -> adapter.toLocal(entity, worldOffset))
                .orElseGet(() -> vanillaToLocal(worldOffset, entity.getYRot(), entity.getXRot()));
    }

    public static Vec3 toWorldOffset(Entity entity, Vec3 localOffset) {
        if (entity instanceof AbstractContraptionEntity) {
            return localOffset;
        }

        if (entity instanceof ControlledContraptionEntity controlledContraption) {
            return controlledContraption.applyRotation(localOffset, CURRENT_TICK_PARTIAL);
        }

        return resolveAdapter(entity)
                .flatMap(adapter -> adapter.toWorld(entity, localOffset))
                .orElseGet(() -> vanillaToWorld(localOffset, entity.getYRot(), entity.getXRot()));
    }

    public static Vec3 captureAnchorSpacePosition(Entity entity, Vec3 worldPosition) {
        if (entity instanceof AbstractContraptionEntity contraptionEntity) {
            return contraptionEntity.toLocalVector(worldPosition, CURRENT_TICK_PARTIAL);
        }

        return toEntityLocal(entity, worldPosition.subtract(entity.position()));
    }

    public static Vec3 resolveWorldPosition(Entity entity, Vec3 anchorSpacePosition) {
        if (entity instanceof AbstractContraptionEntity contraptionEntity) {
            return contraptionEntity.toGlobalVector(anchorSpacePosition, CURRENT_TICK_PARTIAL);
        }

        return entity.position().add(toWorldOffset(entity, anchorSpacePosition));
    }

    private static Optional<RotationAdapter> resolveAdapter(Entity entity) {
        return ADAPTER_CACHE.computeIfAbsent(entity.getClass(), EntityAnchorTransforms::discoverAdapter);
    }

    private static Optional<RotationAdapter> discoverAdapter(Class<?> entityClass) {
        try {
            Method applyRotation = findVec3RotationMethod(entityClass, "applyRotation");
            Method reverseRotation = findVec3RotationMethod(entityClass, "reverseRotation");
            if (applyRotation == null || reverseRotation == null) {
                return Optional.empty();
            }

            applyRotation.setAccessible(true);
            reverseRotation.setAccessible(true);
            return Optional.of(new RotationAdapter(entityClass.getName(), applyRotation, reverseRotation));
        } catch (LinkageError | RuntimeException exception) {
            logDiscoveryFailure(entityClass, exception);
            return Optional.empty();
        }
    }

    private static Method findVec3RotationMethod(Class<?> entityClass, String methodName) {
        for (Class<?> current = entityClass; current != null; current = current.getSuperclass()) {
            try {
                Method method = current.getDeclaredMethod(methodName, Vec3.class, float.class);
                if (Vec3.class.isAssignableFrom(method.getReturnType())) {
                    return method;
                }
            } catch (NoSuchMethodException ignored) {
            }
        }

        try {
            Method method = entityClass.getMethod(methodName, Vec3.class, float.class);
            return Vec3.class.isAssignableFrom(method.getReturnType()) ? method : null;
        } catch (NoSuchMethodException ignored) {
            return null;
        }
    }

    private static Vec3 vanillaToLocal(Vec3 worldOffset, float yRot, float xRot) {
        return worldOffset
                .yRot(toRadians(yRot))
                .xRot(toRadians(xRot));
    }

    private static Vec3 vanillaToWorld(Vec3 localOffset, float yRot, float xRot) {
        return localOffset
                .xRot(-toRadians(xRot))
                .yRot(-toRadians(yRot));
    }

    private static float toRadians(float degrees) {
        return (float) (degrees * (Math.PI / 180.0D));
    }

    private static void logDiscoveryFailure(Class<?> entityClass, Throwable exception) {
        String failureKey = entityClass.getName() + "#discovery";
        if (LOGGED_ADAPTER_FAILURES.add(failureKey)) {
            NorthstarQOLCompat.LOGGER.warn(
                    "Failed to inspect custom spawn anchor transforms on {}; falling back to vanilla yaw/pitch math.",
                    entityClass.getName(),
                    exception);
        }
    }

    private record RotationAdapter(String ownerName, Method applyRotation, Method reverseRotation) {
        private Optional<Vec3> toLocal(Entity entity, Vec3 worldOffset) {
            return invoke(reverseRotation, entity, worldOffset);
        }

        private Optional<Vec3> toWorld(Entity entity, Vec3 localOffset) {
            return invoke(applyRotation, entity, localOffset);
        }

        private Optional<Vec3> invoke(Method method, Entity entity, Vec3 input) {
            try {
                Object result = method.invoke(entity, input, CURRENT_TICK_PARTIAL);
                return result instanceof Vec3 vec3 ? Optional.of(vec3) : Optional.empty();
            } catch (ReflectiveOperationException | RuntimeException exception) {
                logFailure(ownerName, method.getName(), exception);
                return Optional.empty();
            }
        }

        private void logFailure(String ownerName, String methodName, Exception exception) {
            String failureKey = ownerName + "#" + methodName;
            if (LOGGED_ADAPTER_FAILURES.add(failureKey)) {
                NorthstarQOLCompat.LOGGER.warn(
                        "Failed to use custom spawn anchor transform {} on {}; falling back to vanilla yaw/pitch math.",
                        methodName,
                        ownerName,
                        exception);
            }
        }
    }
}
