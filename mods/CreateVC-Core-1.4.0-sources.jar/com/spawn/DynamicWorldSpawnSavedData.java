package com.spawn;

import java.util.Optional;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

public final class DynamicWorldSpawnSavedData extends SavedData {
    private static final String ANCHOR_TAG = "anchor";

    private DynamicWorldSpawnAnchor anchor;

    public Optional<DynamicWorldSpawnAnchor> anchor() {
        return Optional.ofNullable(anchor);
    }

    public void setAnchor(DynamicWorldSpawnAnchor anchor) {
        this.anchor = anchor;
        setDirty();
    }

    public void clearAnchor() {
        if (anchor != null) {
            anchor = null;
            setDirty();
        }
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        if (anchor != null) {
            tag.put(ANCHOR_TAG, anchor.save(new CompoundTag()));
        }
        return tag;
    }

    public static DynamicWorldSpawnSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        DynamicWorldSpawnSavedData data = new DynamicWorldSpawnSavedData();
        if (tag.contains(ANCHOR_TAG, CompoundTag.TAG_COMPOUND)) {
            DynamicWorldSpawnAnchor.load(tag.getCompound(ANCHOR_TAG)).ifPresent(data::setAnchor);
            data.setDirty(false);
        }
        return data;
    }
}
