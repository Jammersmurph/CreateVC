package com.spawn;

import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerRespawnPositionEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

public final class DynamicWorldSpawnRuntime {
    private final DynamicWorldSpawnController controller = new DynamicWorldSpawnController();

    public void onServerTickPost(ServerTickEvent.Post event) {
        controller.tick(event.getServer());
    }

    public void onPlayerRespawnPosition(PlayerRespawnPositionEvent event) {
        controller.onPlayerRespawnPosition(event);
    }

    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        controller.onPlayerRespawn(event);
    }

    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        controller.onPlayerLoggedIn(event);
    }

    public void onServerStopping(ServerStoppingEvent event) {
        controller.clearRuntimeState();
    }

    public DynamicWorldSpawnController controller() {
        return controller;
    }
}
