package com.spawn;

import com.northstarqolcompat.config.NorthstarQOLCompatConfig;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerRespawnPositionEvent;
import org.jetbrains.annotations.Nullable;

public final class DynamicWorldSpawnController {
    private static final String DATA_NAME = "createvc_core_dynamic_world_spawn";
    private static final String PLAYER_LOGIN_STATE_TAG = "createvc_dynamic_spawn_login_state";
    private static final String FIRST_JOIN_SYNCED_TAG = "firstJoinSynced";
    private static final SavedData.Factory<DynamicWorldSpawnSavedData> DATA_FACTORY =
            new SavedData.Factory<>(DynamicWorldSpawnSavedData::new, DynamicWorldSpawnSavedData::load);
    private static final double LOGIN_SNAP_EXTRA_RADIUS = 2.0D;
    private static final int LOGIN_PLACEMENT_ATTEMPTS = 6;
    private static final int RESPAWN_PLACEMENT_ATTEMPTS = 8;
    private static final double FORCE_PLACEMENT_TOLERANCE_SQR = 0.0625D;

    private long lastRefreshTick = Long.MIN_VALUE;
    private String lastStatus = "No dynamic world spawn anchor has been set.";
    private final Map<UUID, PendingPlacement> pendingPlacements = new HashMap<>();

    public void tick(MinecraftServer server) {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            pendingPlacements.clear();
            return;
        }

        if (server.getTickCount() - lastRefreshTick < NorthstarQOLCompatConfig.dynamicWorldSpawnUpdateIntervalTicks) {
            processPendingPlacements(server);
            return;
        }

        refresh(server);
        processPendingPlacements(server);
    }

    public void refresh(MinecraftServer server) {
        lastRefreshTick = server.getTickCount();

        resolve(server).ifPresent(resolved -> {
            if (resolved.level.dimension() == Level.OVERWORLD) {
                resolved.level.setDefaultSpawnPos(BlockPos.containing(resolved.position), resolved.yRot);
                lastStatus = "Dynamic anchor resolved. Vanilla world spawn was updated as a fallback, and bedless respawns should use the live anchor.";
            } else {
                lastStatus = "Anchor resolved outside the overworld. Bedless respawns can follow it, but vanilla first-join world spawn stays overworld.";
            }
        });
    }

    public void onPlayerRespawnPosition(PlayerRespawnPositionEvent event) {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            return;
        }

        ServerPlayer player = (ServerPlayer) event.getEntity();
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        boolean hasPersonalSpawn = player.getRespawnPosition() != null;
        if (hasPersonalSpawn && !NorthstarQOLCompatConfig.forceDynamicSpawnOnAllRespawns) {
            return;
        }

        resolve(server).ifPresent(resolved -> {
            event.setDimensionTransition(new DimensionTransition(
                    resolved.level,
                    resolved.position,
                    Vec3.ZERO,
                    resolved.yRot,
                    resolved.xRot,
                    DimensionTransition.DO_NOTHING));
            event.setCopyOriginalSpawnPosition(false);
        });
    }

    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            return;
        }

        if (event.getEntity() instanceof ServerPlayer player) {
            queuePlacement(player, PlacementReason.RESPAWN, RESPAWN_PLACEMENT_ATTEMPTS);
        }
    }

    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            return;
        }

        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        resolve(server).ifPresent(resolved -> {
            synchronizeLoginSpawn(player, server, resolved);
            queuePlacement(player, PlacementReason.LOGIN, LOGIN_PLACEMENT_ATTEMPTS);
        });
    }

    public void setAnchor(ServerPlayer player, Entity entity) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        DynamicWorldSpawnAnchor anchor = DynamicWorldSpawnAnchor.capture(player, entity);
        storeAnchor(server, anchor);
    }

    public boolean setAnchorFromCurrentPosition(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return false;
        }

        Optional<DynamicWorldSpawnAnchor> subLevelAnchor = SableSubLevelAnchorSupport.capture(player);
        if (subLevelAnchor.isEmpty()) {
            return false;
        }

        storeAnchor(server, subLevelAnchor.get());
        return true;
    }

    private void storeAnchor(MinecraftServer server, DynamicWorldSpawnAnchor anchor) {
        getOrCreateData(server).setAnchor(anchor);
        lastRefreshTick = Long.MIN_VALUE;
        lastStatus = "Anchor stored for " + anchor.displayName() + ".";
        refresh(server);
    }

    public boolean clear(MinecraftServer server) {
        DynamicWorldSpawnSavedData data = getData(server);
        if (data == null || data.anchor().isEmpty()) {
            lastStatus = "No dynamic world spawn anchor was active.";
            return false;
        }

        data.clearAnchor();
        lastStatus = "Dynamic world spawn anchor cleared.";
        return true;
    }

    public Optional<DynamicWorldSpawnAnchor> anchor(MinecraftServer server) {
        DynamicWorldSpawnSavedData data = getData(server);
        return data == null ? Optional.empty() : data.anchor();
    }

    public Optional<Component> status(MinecraftServer server) {
        Optional<DynamicWorldSpawnAnchor> anchor = anchor(server);
        if (anchor.isEmpty()) {
            return Optional.of(Component.literal(lastStatus));
        }

        return resolve(server)
                .<Component>map(resolved -> Component.literal(String.format(
                        "Dynamic anchor: %s | type=%s | dimension=%s | pos=%.2f, %.2f, %.2f | yaw=%.1f",
                        resolved.anchor.displayName(),
                        resolved.anchor.entityTypeId(),
                        resolved.level.dimension().location(),
                        resolved.position.x,
                        resolved.position.y,
                        resolved.position.z,
                        resolved.yRot)))
                .or(() -> Optional.of(Component.literal(lastStatus)));
    }

    public Optional<ResolvedAnchorView> resolvedAnchorView(MinecraftServer server) {
        return resolve(server).map(ResolvedAnchor::toView);
    }

    public void clearRuntimeState() {
        lastRefreshTick = Long.MIN_VALUE;
        lastStatus = "No dynamic world spawn anchor has been set.";
        pendingPlacements.clear();
    }

    private Optional<ResolvedAnchor> resolve(MinecraftServer server) {
        DynamicWorldSpawnSavedData data = getData(server);
        if (data == null || data.anchor().isEmpty()) {
            lastStatus = "No dynamic world spawn anchor has been set.";
            return Optional.empty();
        }

        DynamicWorldSpawnAnchor anchor = data.anchor().get();
        ServerLevel level = server.getLevel(anchor.dimension());
        if (level == null) {
            lastStatus = "Anchor dimension is not available: " + anchor.dimension().location();
            return Optional.empty();
        }

        if (anchor.subLevelUuid() != null) {
            Optional<SableSubLevelAnchorSupport.ResolvedSubLevelAnchor> resolvedSubLevel =
                    SableSubLevelAnchorSupport.resolve(server, anchor);
            if (resolvedSubLevel.isEmpty()) {
                lastStatus = "Anchor moving platform is missing or unloaded: " + anchor.displayName();
                return Optional.empty();
            }

            SableSubLevelAnchorSupport.ResolvedSubLevelAnchor subLevelAnchor = resolvedSubLevel.get();
            return Optional.of(new ResolvedAnchor(
                    anchor,
                    subLevelAnchor.level(),
                    null,
                    subLevelAnchor.position(),
                    anchor.resolveAbsoluteYaw(),
                    anchor.pitch()));
        }

        Entity entity = level.getEntity(anchor.entityUuid());
        if (entity == null || !entity.isAlive()) {
            lastStatus = "Anchor entity is missing or unloaded: " + anchor.displayName();
            return Optional.empty();
        }

        Vec3 worldPosition = anchor.resolveWorldPosition(entity);
        return Optional.of(new ResolvedAnchor(anchor, level, entity, worldPosition, anchor.resolveYaw(entity), anchor.pitch()));
    }

    private void synchronizeLoginSpawn(ServerPlayer player, MinecraftServer server, ResolvedAnchor resolved) {
        if (shouldForceFirstJoinPlacement(player)) {
            teleportPlayerToResolvedAnchor(player, resolved);
            markFirstJoinPlacementComplete(player);
            return;
        }

        snapPlayerNearAnchorToExactSpawn(player, server, resolved);
    }

    private void snapPlayerNearAnchorToExactSpawn(ServerPlayer player, MinecraftServer server, ResolvedAnchor resolved) {
        if (player.serverLevel() != resolved.level) {
            return;
        }

        double allowedHorizontalDistance = server.getGameRules().getInt(GameRules.RULE_SPAWN_RADIUS) + LOGIN_SNAP_EXTRA_RADIUS;
        Vec3 currentPosition = player.position();
        if (horizontalDistanceSquared(currentPosition, resolved.position) > allowedHorizontalDistance * allowedHorizontalDistance) {
            return;
        }

        if (currentPosition.distanceToSqr(resolved.position) < 0.01D) {
            return;
        }

        teleportPlayerToResolvedAnchor(player, resolved);
    }

    private boolean shouldForceFirstJoinPlacement(ServerPlayer player) {
        return !player.getPersistentData()
                .getCompound(PLAYER_LOGIN_STATE_TAG)
                .getBoolean(FIRST_JOIN_SYNCED_TAG);
    }

    private void markFirstJoinPlacementComplete(ServerPlayer player) {
        var persistentData = player.getPersistentData();
        var loginState = persistentData.getCompound(PLAYER_LOGIN_STATE_TAG);
        loginState.putBoolean(FIRST_JOIN_SYNCED_TAG, true);
        persistentData.put(PLAYER_LOGIN_STATE_TAG, loginState);
    }

    private void teleportPlayerToResolvedAnchor(ServerPlayer player, ResolvedAnchor resolved) {
        player.teleportTo(
                resolved.level,
                resolved.position.x,
                resolved.position.y,
                resolved.position.z,
                resolved.yRot,
                resolved.xRot);
        player.setDeltaMovement(Vec3.ZERO);
        player.fallDistance = 0.0F;
    }

    private void queuePlacement(ServerPlayer player, PlacementReason reason, int attemptsRemaining) {
        pendingPlacements.put(player.getUUID(), new PendingPlacement(reason, attemptsRemaining));
    }

    private void processPendingPlacements(MinecraftServer server) {
        if (pendingPlacements.isEmpty()) {
            return;
        }

        Optional<ResolvedAnchor> resolvedAnchor = resolve(server);
        Iterator<Map.Entry<UUID, PendingPlacement>> iterator = pendingPlacements.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, PendingPlacement> entry = iterator.next();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                iterator.remove();
                continue;
            }

            PendingPlacement pendingPlacement = entry.getValue();
            if (pendingPlacement.attemptsRemaining <= 0) {
                iterator.remove();
                continue;
            }

            if (resolvedAnchor.isEmpty()) {
                entry.setValue(pendingPlacement.nextAttempt());
                continue;
            }

            ResolvedAnchor resolved = resolvedAnchor.get();
            if (shouldForcePlacement(player, resolved, pendingPlacement.reason)) {
                teleportPlayerToResolvedAnchor(player, resolved);
            }

            PendingPlacement nextPlacement = pendingPlacement.nextAttempt();
            if (nextPlacement.attemptsRemaining <= 0) {
                iterator.remove();
            } else {
                entry.setValue(nextPlacement);
            }
        }
    }

    private boolean shouldForcePlacement(ServerPlayer player, ResolvedAnchor resolved, PlacementReason reason) {
        if (player.serverLevel() != resolved.level) {
            return true;
        }

        if (reason == PlacementReason.RESPAWN) {
            return player.position().distanceToSqr(resolved.position) > FORCE_PLACEMENT_TOLERANCE_SQR;
        }

        double allowedHorizontalDistance = player.serverLevel()
                .getGameRules()
                .getInt(GameRules.RULE_SPAWN_RADIUS) + LOGIN_SNAP_EXTRA_RADIUS;
        return horizontalDistanceSquared(player.position(), resolved.position) <= allowedHorizontalDistance * allowedHorizontalDistance
                || player.position().distanceToSqr(resolved.position) > FORCE_PLACEMENT_TOLERANCE_SQR;
    }

    @Nullable
    private DynamicWorldSpawnSavedData getData(MinecraftServer server) {
        return server.overworld().getDataStorage().get(DATA_FACTORY, DATA_NAME);
    }

    private DynamicWorldSpawnSavedData getOrCreateData(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(DATA_FACTORY, DATA_NAME);
    }

    private static double horizontalDistanceSquared(Vec3 left, Vec3 right) {
        double dx = left.x - right.x;
        double dz = left.z - right.z;
        return dx * dx + dz * dz;
    }

    private record ResolvedAnchor(
            DynamicWorldSpawnAnchor anchor,
            ServerLevel level,
            @Nullable Entity entity,
            Vec3 position,
            float yRot,
            float xRot) {
        private ResolvedAnchorView toView() {
            return new ResolvedAnchorView(anchor, level, entity, position, yRot, xRot);
        }
    }

    public record ResolvedAnchorView(
            DynamicWorldSpawnAnchor anchor,
            ServerLevel level,
            @Nullable Entity entity,
            Vec3 position,
            float yRot,
            float xRot) {
    }

    private record PendingPlacement(PlacementReason reason, int attemptsRemaining) {
        private PendingPlacement nextAttempt() {
            return new PendingPlacement(reason, attemptsRemaining - 1);
        }
    }

    private enum PlacementReason {
        LOGIN,
        RESPAWN
    }
}
