package com.spawn;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public final class SpawnCreateCompat {
    private SpawnCreateCompat() {
    }

    public static boolean isCreateContraptionEntity(Entity entity) {
        ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        return key != null && "create".equals(key.getNamespace()) && key.getPath().contains("contraption");
    }
}
