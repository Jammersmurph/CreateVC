package com.spawn;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public record DynamicWorldSpawnAnchor(
        ResourceKey<Level> dimension,
        @Nullable UUID entityUuid,
        @Nullable UUID subLevelUuid,
        Vec3 relativeOffset,
        float yawOffset,
        float pitch,
        String entityTypeId,
        String displayName) {
    private static final String DIMENSION_TAG = "dimension";
    private static final String ENTITY_UUID_TAG = "entityUuid";
    private static final String SUBLEVEL_UUID_TAG = "subLevelUuid";
    private static final String OFFSET_X_TAG = "offsetX";
    private static final String OFFSET_Y_TAG = "offsetY";
    private static final String OFFSET_Z_TAG = "offsetZ";
    private static final String YAW_OFFSET_TAG = "yawOffset";
    private static final String PITCH_TAG = "pitch";
    private static final String ENTITY_TYPE_TAG = "entityType";
    private static final String DISPLAY_NAME_TAG = "displayName";

    public static DynamicWorldSpawnAnchor capture(ServerPlayer player, Entity entity) {
        Optional<DynamicWorldSpawnAnchor> subLevelAnchor = SableSubLevelAnchorSupport.capture(player);
        if (subLevelAnchor.isPresent()) {
            return subLevelAnchor.get();
        }

        Entity normalizedEntity = SpawnAnchorEntityResolver.normalize(entity);
        Vec3 snappedFeetPosition = snapFeetPositionToSupportingBlock(player);
        Vec3 localOffset = EntityAnchorTransforms.captureAnchorSpacePosition(normalizedEntity, snappedFeetPosition);
        ResourceLocation entityTypeId = normalizedEntity.getType().builtInRegistryHolder().key().location();

        return new DynamicWorldSpawnAnchor(
                normalizedEntity.level().dimension(),
                normalizedEntity.getUUID(),
                null,
                localOffset,
                player.getYRot() - normalizedEntity.getYRot(),
                player.getXRot(),
                entityTypeId.toString(),
                normalizedEntity.getDisplayName().getString());
    }

    public static DynamicWorldSpawnAnchor forSubLevel(
            ResourceKey<Level> dimension,
            UUID subLevelUuid,
            Vec3 localPosition,
            float yaw,
            float pitch,
            String anchorTypeId,
            String displayName) {
        return new DynamicWorldSpawnAnchor(
                dimension,
                null,
                subLevelUuid,
                localPosition,
                yaw,
                pitch,
                anchorTypeId,
                displayName);
    }

    public CompoundTag save(CompoundTag tag) {
        tag.putString(DIMENSION_TAG, dimension.location().toString());
        if (entityUuid != null) {
            tag.putUUID(ENTITY_UUID_TAG, entityUuid);
        }
        if (subLevelUuid != null) {
            tag.putUUID(SUBLEVEL_UUID_TAG, subLevelUuid);
        }
        tag.putDouble(OFFSET_X_TAG, relativeOffset.x);
        tag.putDouble(OFFSET_Y_TAG, relativeOffset.y);
        tag.putDouble(OFFSET_Z_TAG, relativeOffset.z);
        tag.putFloat(YAW_OFFSET_TAG, yawOffset);
        tag.putFloat(PITCH_TAG, pitch);
        tag.putString(ENTITY_TYPE_TAG, entityTypeId);
        tag.putString(DISPLAY_NAME_TAG, displayName);
        return tag;
    }

    public static Optional<DynamicWorldSpawnAnchor> load(CompoundTag tag) {
        if (!tag.contains(DIMENSION_TAG)) {
            return Optional.empty();
        }

        ResourceLocation dimensionId = ResourceLocation.tryParse(tag.getString(DIMENSION_TAG));
        if (dimensionId == null) {
            return Optional.empty();
        }

        UUID entityUuid = tag.hasUUID(ENTITY_UUID_TAG) ? tag.getUUID(ENTITY_UUID_TAG) : null;
        UUID subLevelUuid = tag.hasUUID(SUBLEVEL_UUID_TAG) ? tag.getUUID(SUBLEVEL_UUID_TAG) : null;
        if (entityUuid == null && subLevelUuid == null) {
            return Optional.empty();
        }

        return Optional.of(new DynamicWorldSpawnAnchor(
                ResourceKey.create(Registries.DIMENSION, dimensionId),
                entityUuid,
                subLevelUuid,
                new Vec3(tag.getDouble(OFFSET_X_TAG), tag.getDouble(OFFSET_Y_TAG), tag.getDouble(OFFSET_Z_TAG)),
                tag.getFloat(YAW_OFFSET_TAG),
                tag.getFloat(PITCH_TAG),
                tag.getString(ENTITY_TYPE_TAG),
                tag.getString(DISPLAY_NAME_TAG)));
    }

    public Vec3 resolveWorldPosition(Entity entity) {
        return EntityAnchorTransforms.resolveWorldPosition(entity, relativeOffset);
    }

    public float resolveYaw(Entity entity) {
        return entity.getYRot() + yawOffset;
    }

    public float resolveAbsoluteYaw() {
        return yawOffset;
    }

    static Vec3 snapFeetPositionToSupportingBlock(ServerPlayer player) {
        Vec3 feetPosition = player.position();
        BlockPos supportingBlock = BlockPos.containing(feetPosition.x, feetPosition.y - 0.2D, feetPosition.z);
        return new Vec3(supportingBlock.getX() + 0.5D, feetPosition.y, supportingBlock.getZ() + 0.5D);
    }
}
