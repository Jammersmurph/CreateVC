package com.spawn;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.northstarqolcompat.config.NorthstarQOLCompatConfig;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class SableSubLevelAnchorSupport {
    private static final ReflectionAccess REFLECTION = ReflectionAccess.create();
    private static final ConcurrentMap<String, Long> FAILURE_BACKOFF_UNTIL = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Long> LAST_FAILURE_LOG = new ConcurrentHashMap<>();

    private SableSubLevelAnchorSupport() {
    }

    public static Optional<DynamicWorldSpawnAnchor> capture(ServerPlayer player) {
        if (!REFLECTION.available) {
            return Optional.empty();
        }
        if (isInFailureBackoff(player.serverLevel(), "capture")) {
            return Optional.empty();
        }

        return findContainingSubLevel(player.serverLevel(), player.getBoundingBox()).flatMap(subLevel -> {
            try {
                Object pose = REFLECTION.logicalPoseMethod.invoke(subLevel);
                Vec3 snappedFeetPosition = DynamicWorldSpawnAnchor.snapFeetPositionToSupportingBlock(player);
                Vec3 localPosition = REFLECTION.transformPositionInverse(pose, snappedFeetPosition);
                UUID subLevelUuid = (UUID) REFLECTION.subLevelUniqueIdMethod.invoke(subLevel);
                String displayName = String.valueOf(REFLECTION.subLevelNameMethod.invoke(subLevel));

                return Optional.of(DynamicWorldSpawnAnchor.forSubLevel(
                        player.serverLevel().dimension(),
                        subLevelUuid,
                        localPosition,
                        player.getYRot(),
                        player.getXRot(),
                        "sable:sublevel",
                        displayName == null || displayName.isBlank() ? "Moving Platform" : displayName));
            } catch (ReflectiveOperationException | RuntimeException exception) {
                logFailure(player.serverLevel(), "capture", exception);
                return Optional.empty();
            }
        });
    }

    public static Optional<ResolvedSubLevelAnchor> resolve(MinecraftServer server, DynamicWorldSpawnAnchor anchor) {
        if (!REFLECTION.available || anchor.subLevelUuid() == null) {
            return Optional.empty();
        }

        ServerLevel level = server.getLevel(anchor.dimension());
        if (level == null) {
            return Optional.empty();
        }
        if (isInFailureBackoff(level, "resolve")) {
            return Optional.empty();
        }

        try {
            Object subLevel = findSubLevel(level, anchor.subLevelUuid());
            if (subLevel == null) {
                return Optional.empty();
            }

            Object pose = REFLECTION.logicalPoseMethod.invoke(subLevel);
            Vec3 worldPosition = REFLECTION.transformPosition(pose, anchor.relativeOffset());
            String displayName = String.valueOf(REFLECTION.subLevelNameMethod.invoke(subLevel));
            return Optional.of(new ResolvedSubLevelAnchor(level, worldPosition, displayName));
        } catch (ReflectiveOperationException | RuntimeException exception) {
            logFailure(level, "resolve", exception);
            return Optional.empty();
        }
    }

    private static Optional<Object> findContainingSubLevel(ServerLevel level, AABB playerBox) {
        try {
            Object container = REFLECTION.getContainer(level);
            if (container == null) {
                return Optional.empty();
            }

            @SuppressWarnings("unchecked")
            Collection<Object> subLevels = (Collection<Object>) REFLECTION.getAllSubLevelsMethod.invoke(container);
            return subLevels.stream()
                    .filter(subLevel -> subLevel != null)
                    .filter(subLevel -> subLevelContains(subLevel, playerBox))
                    .findFirst();
        } catch (ReflectiveOperationException | RuntimeException exception) {
            logFailure(level, "findContainingSubLevel", exception);
            return Optional.empty();
        }
    }

    private static boolean subLevelContains(Object subLevel, AABB playerBox) {
        try {
            Object boundingBox = REFLECTION.subLevelBoundingBoxMethod.invoke(subLevel);
            return boundingBox != null && REFLECTION.boundingBoxIntersects(boundingBox, playerBox);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            logFailure(null, "subLevelContains", exception);
            return false;
        }
    }

    private static Object findSubLevel(ServerLevel level, UUID subLevelUuid) throws ReflectiveOperationException {
        Object container = REFLECTION.getContainer(level);
        if (container == null) {
            return null;
        }

        @SuppressWarnings("unchecked")
        Collection<Object> subLevels = (Collection<Object>) REFLECTION.getAllSubLevelsMethod.invoke(container);
        for (Object subLevel : subLevels) {
            if (subLevel == null) {
                continue;
            }

            UUID currentSubLevelUuid = (UUID) REFLECTION.subLevelUniqueIdMethod.invoke(subLevel);
            if (subLevelUuid.equals(currentSubLevelUuid)) {
                return subLevel;
            }
        }

        return null;
    }

    private static void logFailure(ServerLevel level, String phase, Throwable exception) {
        long now = level == null ? System.currentTimeMillis() : level.getGameTime();
        String key = failureKey(level, phase);
        int backoffTicks = Math.max(0, NorthstarQOLCompatConfig.physicsFailureBackoffTicks);
        if (level != null && backoffTicks > 0) {
            FAILURE_BACKOFF_UNTIL.put(key, now + backoffTicks);
        }

        long lastLogged = LAST_FAILURE_LOG.getOrDefault(key, Long.MIN_VALUE);
        if (lastLogged != Long.MIN_VALUE && now - lastLogged < 40L) {
            return;
        }
        LAST_FAILURE_LOG.put(key, now);
        NorthstarQOLCompat.LOGGER.warn("Sable sublevel moving-spawn support failed during {}.", phase, exception);
    }

    private static boolean isInFailureBackoff(ServerLevel level, String phase) {
        if (level == null || NorthstarQOLCompatConfig.physicsFailureBackoffTicks <= 0) {
            return false;
        }
        return FAILURE_BACKOFF_UNTIL.getOrDefault(failureKey(level, phase), Long.MIN_VALUE) >= level.getGameTime();
    }

    private static String failureKey(ServerLevel level, String phase) {
        String dimension = level == null ? "unknown" : level.dimension().location().toString();
        return dimension + "|" + phase;
    }

    public record ResolvedSubLevelAnchor(ServerLevel level, Vec3 position, String displayName) {
    }

    private static final class ReflectionAccess {
        private final boolean available;
        private final MethodHandle getContainerMethod;
        private final Method getAllSubLevelsMethod;
        private final Method subLevelBoundingBoxMethod;
        private final Method logicalPoseMethod;
        private final Method subLevelUniqueIdMethod;
        private final Method subLevelNameMethod;
        private final ConcurrentMap<Class<?>, Method> boundingBoxIntersectsMethodCache;
        private final ConcurrentMap<Class<?>, Method> transformPositionMethodCache;
        private final ConcurrentMap<Class<?>, Method> transformPositionInverseMethodCache;

        private ReflectionAccess(
                boolean available,
                MethodHandle getContainerMethod,
                Method getAllSubLevelsMethod,
                Method subLevelBoundingBoxMethod,
                Method logicalPoseMethod,
                Method subLevelUniqueIdMethod,
                Method subLevelNameMethod,
                ConcurrentMap<Class<?>, Method> boundingBoxIntersectsMethodCache,
                ConcurrentMap<Class<?>, Method> transformPositionMethodCache,
                ConcurrentMap<Class<?>, Method> transformPositionInverseMethodCache) {
            this.available = available;
            this.getContainerMethod = getContainerMethod;
            this.getAllSubLevelsMethod = getAllSubLevelsMethod;
            this.subLevelBoundingBoxMethod = subLevelBoundingBoxMethod;
            this.logicalPoseMethod = logicalPoseMethod;
            this.subLevelUniqueIdMethod = subLevelUniqueIdMethod;
            this.subLevelNameMethod = subLevelNameMethod;
            this.boundingBoxIntersectsMethodCache = boundingBoxIntersectsMethodCache;
            this.transformPositionMethodCache = transformPositionMethodCache;
            this.transformPositionInverseMethodCache = transformPositionInverseMethodCache;
        }

        private Object getContainer(ServerLevel level) throws ReflectiveOperationException {
            try {
                return getContainerMethod.invoke(level);
            } catch (RuntimeException exception) {
                throw exception;
            } catch (Throwable throwable) {
                throw new ReflectiveOperationException("Failed to access Sable sub-level container.", throwable);
            }
        }

        private boolean boundingBoxIntersects(Object boundingBox, AABB playerBox) throws ReflectiveOperationException {
            Method method = resolveRuntimeMethod(
                    boundingBoxIntersectsMethodCache,
                    boundingBox.getClass(),
                    "intersects",
                    AABB.class);
            return Boolean.TRUE.equals(method.invoke(boundingBox, playerBox));
        }

        private Vec3 transformPosition(Object pose, Vec3 worldPosition) throws ReflectiveOperationException {
            Method method = resolveRuntimeMethod(
                    transformPositionMethodCache,
                    pose.getClass(),
                    "transformPosition",
                    Vec3.class);
            return (Vec3) method.invoke(pose, worldPosition);
        }

        private Vec3 transformPositionInverse(Object pose, Vec3 worldPosition) throws ReflectiveOperationException {
            Method method = resolveRuntimeMethod(
                    transformPositionInverseMethodCache,
                    pose.getClass(),
                    "transformPositionInverse",
                    Vec3.class);
            return (Vec3) method.invoke(pose, worldPosition);
        }

        private static ReflectionAccess create() {
            try {
                ClassLoader classLoader = SableSubLevelAnchorSupport.class.getClassLoader();
                Class<?> subLevelContainerClass = Class.forName(
                        "dev.ryanhcode.sable.api.sublevel.SubLevelContainer",
                        false,
                        classLoader);
                Class<?> serverSubLevelContainerClass = Class.forName(
                        "dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer",
                        false,
                        classLoader);
                Class<?> subLevelClass = Class.forName(
                        "dev.ryanhcode.sable.sublevel.SubLevel",
                        false,
                        classLoader);

                MethodHandle getContainerMethod = findStaticMethod(
                        serverSubLevelContainerClass,
                        subLevelContainerClass,
                        "getContainer",
                        MethodType.methodType(serverSubLevelContainerClass, ServerLevel.class));
                Method getAllSubLevelsMethod = findDeclaredMethod(serverSubLevelContainerClass, "getAllSubLevels");
                Method subLevelBoundingBoxMethod = findDeclaredMethod(subLevelClass, "boundingBox");
                Method logicalPoseMethod = findDeclaredMethod(subLevelClass, "logicalPose");
                Method subLevelUniqueIdMethod = findDeclaredMethod(subLevelClass, "getUniqueId");
                Method subLevelNameMethod = findDeclaredMethod(subLevelClass, "getName");

                return new ReflectionAccess(
                        true,
                        getContainerMethod,
                        getAllSubLevelsMethod,
                        subLevelBoundingBoxMethod,
                        logicalPoseMethod,
                        subLevelUniqueIdMethod,
                        subLevelNameMethod,
                        new ConcurrentHashMap<>(),
                        new ConcurrentHashMap<>(),
                        new ConcurrentHashMap<>());
            } catch (ReflectiveOperationException | RuntimeException | LinkageError exception) {
                NorthstarQOLCompat.LOGGER.info(
                        "Sable sublevel moving-spawn support is unavailable in this environment.",
                        exception);
                return new ReflectionAccess(
                        false,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        new ConcurrentHashMap<>(),
                        new ConcurrentHashMap<>(),
                        new ConcurrentHashMap<>());
            }
        }

        private static Method findDeclaredMethod(Class<?> owner, String methodName, Class<?>... parameterTypes)
                throws NoSuchMethodException {
            Method method = owner.getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            return method;
        }

        private static MethodHandle findStaticMethod(
                Class<?> preferredOwner,
                Class<?> fallbackOwner,
                String methodName,
                MethodType methodType) throws NoSuchMethodException, IllegalAccessException {
            MethodHandles.Lookup publicLookup = MethodHandles.publicLookup();
            try {
                return publicLookup.findStatic(preferredOwner, methodName, methodType);
            } catch (NoSuchMethodException ignored) {
                return publicLookup.findStatic(fallbackOwner, methodName, methodType);
            }
        }

        private static Method resolveRuntimeMethod(
                ConcurrentMap<Class<?>, Method> cache,
                Class<?> owner,
                String methodName,
                Class<?>... parameterTypes) throws NoSuchMethodException {
            Method cached = cache.get(owner);
            if (cached != null) {
                return cached;
            }

            Method resolved;
            try {
                resolved = owner.getMethod(methodName, parameterTypes);
            } catch (NoSuchMethodException exception) {
                resolved = owner.getDeclaredMethod(methodName, parameterTypes);
            }
            resolved.setAccessible(true);
            Method existing = cache.putIfAbsent(owner, resolved);
            return existing != null ? existing : resolved;
        }
    }
}
