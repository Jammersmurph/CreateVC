package com.northstarqolcompat;

import com.northstarqolcompat.command.DynamicWorldSpawnCommand;
import com.northstarqolcompat.command.ChainCommand;
import com.northstarqolcompat.compat.FunctionalStorageContraptionCompat;
import com.northstarqolcompat.config.NorthstarQOLCompatConfig;
import com.northstarqolcompat.network.CreateVCUiPackets;
import com.spawn.DynamicWorldSpawnRuntime;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(NorthstarQOLCompat.MODID)
public class NorthstarQOLCompat {

    public static final String MODID  = "createvc_core";
    public static final Logger LOGGER = LogManager.getLogger(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    private static DynamicWorldSpawnRuntime dynamicWorldSpawnRuntime;

    public NorthstarQOLCompat(IEventBus modEventBus, ModContainer modContainer) {
        LOGGER.info("[CreateVC-Core] Initialising core server tools and pack fixes.");
        modContainer.registerConfig(ModConfig.Type.SERVER, NorthstarQOLCompatConfig.SPEC);
        modEventBus.addListener(this::setup);
        modEventBus.addListener(CreateVCUiPackets::register);

        dynamicWorldSpawnRuntime = new DynamicWorldSpawnRuntime();
        NeoForge.EVENT_BUS.addListener(dynamicWorldSpawnRuntime::onServerTickPost);
        NeoForge.EVENT_BUS.addListener(dynamicWorldSpawnRuntime::onPlayerRespawnPosition);
        NeoForge.EVENT_BUS.addListener(dynamicWorldSpawnRuntime::onPlayerRespawn);
        NeoForge.EVENT_BUS.addListener(dynamicWorldSpawnRuntime::onPlayerLoggedIn);
        NeoForge.EVENT_BUS.addListener(dynamicWorldSpawnRuntime::onServerStopping);
        NeoForge.EVENT_BUS.addListener(DynamicWorldSpawnCommand::register);
        NeoForge.EVENT_BUS.addListener(ChainCommand::onRegisterCommands);
    }

    private void setup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            if (ModList.get().isLoaded("functionalstorage") && ModList.get().isLoaded("create")) {
                try {
                    FunctionalStorageContraptionCompat.register();
                    LOGGER.info("[CreateVC-Core] Functional Storage contraption support registered.");
                } catch (LinkageError | RuntimeException exception) {
                    LOGGER.warn("[CreateVC-Core] Skipping Functional Storage contraption support because Create APIs were unavailable.", exception);
                }
            }
            LOGGER.info("[CreateVC-Core] Common setup complete.");
        });
    }

    public static DynamicWorldSpawnRuntime dynamicWorldSpawnRuntime() {
        return dynamicWorldSpawnRuntime;
    }
}
