package com.northstarqolcompat.network;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.northstarqolcompat.command.ClaimShopCommand;
import com.northstarqolcompat.command.StarterKitCommand;
import io.netty.buffer.ByteBuf;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class CreateVCUiPackets {
    private static volatile OpenRequest pendingOpenRequest;

    private CreateVCUiPackets() {
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(NorthstarQOLCompat.MODID)
                .versioned("3")
                .optional();

        registrar.playToClient(OpenScreenPayload.TYPE, OpenScreenPayload.STREAM_CODEC, (payload, context) ->
                pendingOpenRequest = new OpenRequest(
                        payload.screenId(),
                        payload.spurs(),
                        payload.cooldownSeconds(),
                        payload.allowServerClaim(),
                        payload.selectedValue()));

        registrar.playToServer(UiActionPayload.TYPE, UiActionPayload.STREAM_CODEC, (payload, context) ->
                context.enqueueWork(() -> {
                    if (!(context.player() instanceof ServerPlayer player)) {
                        return;
                    }

                    switch (payload.actionId()) {
                        case "starterkit.buy" -> StarterKitCommand.buyStarterKit(player);
                        case "claimshop.buy" -> ClaimShopCommand.buy(player, payload.value());
                        default -> player.sendSystemMessage(Component.literal("[CreateVC UI] Unknown action: " + payload.actionId())
                                .withStyle(ChatFormatting.RED));
                    }
                }));
    }

    public static Optional<OpenRequest> consumePendingOpenRequest() {
        OpenRequest request = pendingOpenRequest;
        pendingOpenRequest = null;
        return Optional.ofNullable(request);
    }

    public static void openStarterKit(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new OpenScreenPayload(
                "starterkit",
                StarterKitCommand.countSpurs(player),
                StarterKitCommand.getRemainingCooldownSeconds(player),
                false,
                ""));
    }

    public static void openClaimShop(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new OpenScreenPayload(
                "claimshop",
                ClaimShopCommand.countSpurs(player),
                0L,
                false,
                ""));
    }

    public record OpenRequest(
            String screenId,
            int spurs,
            long cooldownSeconds,
            boolean allowServerClaim,
            String selectedValue) {
    }

    public record OpenScreenPayload(
            String screenId,
            int spurs,
            long cooldownSeconds,
            boolean allowServerClaim,
            String selectedValue) implements CustomPacketPayload {

        public static final ResourceLocation ID_LOC =
                ResourceLocation.fromNamespaceAndPath(NorthstarQOLCompat.MODID, "open_ui_screen");
        public static final Type<OpenScreenPayload> TYPE = new Type<>(ID_LOC);
        public static final StreamCodec<ByteBuf, OpenScreenPayload> STREAM_CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.STRING_UTF8, OpenScreenPayload::screenId,
                        ByteBufCodecs.VAR_INT, OpenScreenPayload::spurs,
                        ByteBufCodecs.VAR_LONG, OpenScreenPayload::cooldownSeconds,
                        ByteBufCodecs.BOOL, OpenScreenPayload::allowServerClaim,
                        ByteBufCodecs.STRING_UTF8, OpenScreenPayload::selectedValue,
                        OpenScreenPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record UiActionPayload(String actionId, String value) implements CustomPacketPayload {
        public static final ResourceLocation ID_LOC =
                ResourceLocation.fromNamespaceAndPath(NorthstarQOLCompat.MODID, "ui_action");
        public static final Type<UiActionPayload> TYPE = new Type<>(ID_LOC);
        public static final StreamCodec<ByteBuf, UiActionPayload> STREAM_CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.STRING_UTF8, UiActionPayload::actionId,
                        ByteBufCodecs.STRING_UTF8, UiActionPayload::value,
                        UiActionPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}
