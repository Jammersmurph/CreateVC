package com.northstarqolcompat.client.title;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public class CreateVCLogoRenderer {

    private static final ResourceLocation LOGO =
        ResourceLocation.fromNamespaceAndPath("createvc_core", "textures/gui/title_logo.png");

    private static final int LOGO_WIDTH  = 220;
    private static final int LOGO_HEIGHT = 147;

    public static void render(GuiGraphics graphics, int screenWidth, float transparency) {
        int x = (screenWidth - LOGO_WIDTH) / 2;
        int y = 10;
        graphics.setColor(1.0F, 1.0F, 1.0F, transparency);
        graphics.blit(LOGO, x, y, 0, 0, LOGO_WIDTH, LOGO_HEIGHT, LOGO_WIDTH, LOGO_HEIGHT);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void renderAtScale(GuiGraphics graphics, int screenWidth, int y, float scale, float transparency) {
        int drawW = (int)(LOGO_WIDTH * scale);
        int drawH = (int)(LOGO_HEIGHT * scale);
        int x = (screenWidth - drawW) / 2;
        graphics.setColor(1.0F, 1.0F, 1.0F, transparency);
        graphics.blit(LOGO, x, y, drawW, drawH, 0, 0, LOGO_WIDTH, LOGO_HEIGHT, LOGO_WIDTH, LOGO_HEIGHT);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void renderCentered(GuiGraphics graphics, int screenWidth, int screenHeight, float transparency) {
        int x = (screenWidth - LOGO_WIDTH) / 2;
        int y = (screenHeight - LOGO_HEIGHT) / 2 - 20;
        graphics.setColor(1.0F, 1.0F, 1.0F, transparency);
        graphics.blit(LOGO, x, y, 0, 0, LOGO_WIDTH, LOGO_HEIGHT, LOGO_WIDTH, LOGO_HEIGHT);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }
}
