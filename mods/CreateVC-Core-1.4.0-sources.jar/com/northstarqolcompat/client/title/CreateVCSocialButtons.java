package com.northstarqolcompat.client.title;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

public class CreateVCSocialButtons {

    private static final String DISCORD_URL = "https://discord.com/invite/dQR6fJUxAM";
    private static final String WEBSITE_URL = "https://www.createvc.org";

    public static Button createWebsiteButton(int x, int y, int screenWidth) {
        return Button.builder(
                Component.literal("\uD83C\uDF10").setStyle(Style.EMPTY.withColor(0xFFFFFF)),
                btn -> openUrl(WEBSITE_URL))
            .pos(x, y)
            .size(20, 20)
            .tooltip(Tooltip.create(Component.translatable("createvc_core.title.website")))
            .build();
    }

    public static Button createDiscordButton(int x, int y, int screenWidth) {
        return Button.builder(
                Component.literal("DC").setStyle(Style.EMPTY.withColor(0xFFFFFF)),
                btn -> openUrl(DISCORD_URL))
            .pos(x, y)
            .size(20, 20)
            .tooltip(Tooltip.create(Component.translatable("createvc_core.title.discord")))
            .build();
    }

    public static int socialButtonsRightX() {
        int socialButtonWidth = 20;
        int gap = 4;
        return socialButtonWidth * 2 + gap;
    }

    private static void openUrl(String url) {
        Minecraft.getInstance().tell(() ->
            net.minecraft.Util.getPlatform().openUri(url));
    }

}
