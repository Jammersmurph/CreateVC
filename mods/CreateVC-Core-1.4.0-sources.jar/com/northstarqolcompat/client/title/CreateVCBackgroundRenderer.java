package com.northstarqolcompat.client.title;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public class CreateVCBackgroundRenderer {

    private static final ResourceLocation BACKGROUND =
        ResourceLocation.fromNamespaceAndPath("createvc_core", "textures/gui/background.png");

    private static final int BG_WIDTH = 1536;
    private static final int BG_HEIGHT = 1024;

    public static void renderBackgroundFull(GuiGraphics graphics, int screenWidth, int screenHeight) {
        graphics.blit(BACKGROUND, 0, 0, screenWidth, screenHeight, 0, 0, BG_WIDTH, BG_HEIGHT, BG_WIDTH, BG_HEIGHT);
    }

    public static void renderOverlay(GuiGraphics graphics, int width, int height) {
        int gradientHeight = Math.min(160, height / 3);
        graphics.fillGradient(0, 0, width, gradientHeight, 0xC0000000, 0x00000000);
    }
}
