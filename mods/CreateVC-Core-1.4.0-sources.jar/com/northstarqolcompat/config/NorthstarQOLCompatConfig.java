package com.northstarqolcompat.config;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.neoforge.common.ModConfigSpec;

@EventBusSubscriber(modid = NorthstarQOLCompat.MODID, bus = EventBusSubscriber.Bus.MOD)
public class NorthstarQOLCompatConfig {

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    public  static final ModConfigSpec         SPEC;

    private static final ModConfigSpec.BooleanValue ENABLE_DYNAMIC_WORLD_SPAWN;
    private static final ModConfigSpec.IntValue DYNAMIC_WORLD_SPAWN_UPDATE_INTERVAL_TICKS;
    private static final ModConfigSpec.BooleanValue FORCE_DYNAMIC_SPAWN_ON_ALL_RESPAWNS;
    private static final ModConfigSpec.IntValue PHYSICS_FAILURE_BACKOFF_TICKS;
    private static final ModConfigSpec.BooleanValue ENABLE_ITEM_ENTITY_CLEAR_OPTIMIZATION;
    private static final ModConfigSpec.IntValue ITEM_ENTITY_CLEAR_BATCH_SIZE;
    private static final ModConfigSpec.BooleanValue ENABLE_CHAIN_COMMAND;

    public static boolean enableDynamicWorldSpawn = false;
    public static int dynamicWorldSpawnUpdateIntervalTicks = 20;
    public static boolean forceDynamicSpawnOnAllRespawns = false;
    public static int physicsFailureBackoffTicks = 100;
    public static boolean enableItemEntityClearOptimization = false;
    public static int itemEntityClearBatchSize = 100;
    public static boolean enableChainCommand = true;

    static {
        BUILDER.comment("CreateVC Core server config");

        BUILDER.push("dynamicWorldSpawn");
        ENABLE_DYNAMIC_WORLD_SPAWN = BUILDER
                .comment("Enable the moving world spawn anchor system for ships, contraptions, and moving platforms.")
                .define("enabled", false);
        DYNAMIC_WORLD_SPAWN_UPDATE_INTERVAL_TICKS = BUILDER
                .comment("Ticks between dynamic spawn anchor refreshes while an anchor is active.")
                .defineInRange("updateIntervalTicks", 20, 1, 1200);
        FORCE_DYNAMIC_SPAWN_ON_ALL_RESPAWNS = BUILDER
                .comment("When false, moving world spawn only overrides bedless respawns and vanilla world spawn.")
                .define("forceAllRespawns", false);
        PHYSICS_FAILURE_BACKOFF_TICKS = BUILDER
                .comment("Ticks to back off repeated failed optional Sable reflection paths.")
                .defineInRange("physicsFailureBackoffTicks", 100, 0, 1200);
        BUILDER.pop();

        BUILDER.push("commands");
        ENABLE_ITEM_ENTITY_CLEAR_OPTIMIZATION = BUILDER
                .comment("Enable /createvc_batchkill item entity clearing.")
                .define("enableItemEntityClearOptimization", false);
        ITEM_ENTITY_CLEAR_BATCH_SIZE = BUILDER
                .comment("Default number of item entities removed per /createvc_batchkill run.")
                .defineInRange("itemEntityClearBatchSize", 100, 10, 1000);
        ENABLE_CHAIN_COMMAND = BUILDER
                .comment("Enable /chain command to run multiple commands sequentially.")
                .define("enableChainCommand", true);
        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    @SubscribeEvent
    static void onLoad(ModConfigEvent.Loading event) {
        if (event.getConfig().getSpec() != SPEC) return;
        bake();
        NorthstarQOLCompat.LOGGER.info("[CreateVC-Core] Config loaded.");
    }

    @SubscribeEvent
    static void onReload(ModConfigEvent.Reloading event) {
        if (event.getConfig().getSpec() != SPEC) return;
        bake();
        NorthstarQOLCompat.LOGGER.info("[CreateVC-Core] Config reloaded.");
    }

    private static void bake() {
        enableDynamicWorldSpawn = ENABLE_DYNAMIC_WORLD_SPAWN.get();
        dynamicWorldSpawnUpdateIntervalTicks = DYNAMIC_WORLD_SPAWN_UPDATE_INTERVAL_TICKS.get();
        forceDynamicSpawnOnAllRespawns = FORCE_DYNAMIC_SPAWN_ON_ALL_RESPAWNS.get();
        physicsFailureBackoffTicks = PHYSICS_FAILURE_BACKOFF_TICKS.get();
        enableItemEntityClearOptimization = ENABLE_ITEM_ENTITY_CLEAR_OPTIMIZATION.get();
        itemEntityClearBatchSize = ITEM_ENTITY_CLEAR_BATCH_SIZE.get();
        enableChainCommand = ENABLE_CHAIN_COMMAND.get();
    }
}
