package com.northstarqolcompat.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.northstarqolcompat.NorthstarQOLCompat;
import com.northstarqolcompat.network.CreateVCUiPackets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = NorthstarQOLCompat.MODID, bus = EventBusSubscriber.Bus.GAME)
public final class ClaimShopCommand {
    private static final String TITLE = "[CreateVC Claims] ";
    private static final ResourceLocation SPUR_ID = ResourceLocation.parse("numismatics:spur");

    private static final Map<String, ShopEntry> SHOP_ITEMS = createItems();

    private ClaimShopCommand() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("claimshop")
                        .requires(source -> source.getEntity() instanceof ServerPlayer)
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            openMenu(player);
                            return 1;
                        })
                        .then(Commands.literal("buy")
                                .then(Commands.argument("tier", StringArgumentType.word())
                                        .executes(ctx -> {
                                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                                            return buy(player, StringArgumentType.getString(ctx, "tier"));
                                        })))
        );
    }

    public static void openMenu(ServerPlayer player) {
        CreateVCUiPackets.openClaimShop(player);
    }

    public static int buy(ServerPlayer player, String tier) {
        ShopEntry entry = SHOP_ITEMS.get(tier.toLowerCase(Locale.ROOT));
        if (entry == null) {
            sendError(player, "Unknown shop item '" + tier + "'.");
            openMenu(player);
            return 0;
        }

        int currentSpurs = countSpurs(player);
        if (currentSpurs < entry.price()) {
            sendError(player, "You need " + entry.price() + " spurs for " + entry.displayName() + ", but only have " + currentSpurs + ".");
            openMenu(player);
            return 0;
        }

        if (!removeSpurs(player, entry.price())) {
            sendError(player, "Purchase failed while deducting spurs. Try again.");
            openMenu(player);
            return 0;
        }

        Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(entry.itemId()));
        if (item == null || item == Items.AIR) {
            sendError(player, "The configured shop item is missing: " + entry.itemId());
            openMenu(player);
            return 0;
        }

        player.getInventory().placeItemBackInInventory(new ItemStack(item, 1), true);
        player.containerMenu.broadcastChanges();

        sendSuccess(player, "Purchased 1 " + entry.displayName() + " for " + entry.price() + " spurs.");
        player.sendSystemMessage(Component.literal("Remaining spurs: " + countSpurs(player)).withStyle(ChatFormatting.YELLOW));
        openMenu(player);
        return 1;
    }

    public static int countSpurs(ServerPlayer player) {
        Item spurItem = BuiltInRegistries.ITEM.get(SPUR_ID);
        if (spurItem == null || spurItem == Items.AIR) {
            return 0;
        }
        return player.getInventory().countItem(spurItem);
    }

    public static List<ShopEntry> entries() {
        return List.copyOf(SHOP_ITEMS.values());
    }

    private static boolean removeSpurs(ServerPlayer player, int amount) {
        Item spurItem = BuiltInRegistries.ITEM.get(SPUR_ID);
        if (spurItem == null || spurItem == Items.AIR) {
            return false;
        }

        Inventory inventory = player.getInventory();
        int remaining = amount;
        remaining = drainList(inventory.items, spurItem, remaining);
        remaining = drainList(inventory.offhand, spurItem, remaining);

        if (remaining > 0) {
            return false;
        }

        inventory.setChanged();
        player.containerMenu.broadcastChanges();
        return true;
    }

    private static int drainList(List<ItemStack> stacks, Item target, int remaining) {
        for (ItemStack stack : stacks) {
            if (remaining <= 0) {
                break;
            }
            if (!stack.is(target)) {
                continue;
            }

            int taken = Math.min(stack.getCount(), remaining);
            stack.shrink(taken);
            remaining -= taken;
        }
        return remaining;
    }

    private static Map<String, ShopEntry> createItems() {
        Map<String, ShopEntry> items = new LinkedHashMap<>();
        add(items, new ShopEntry("common", "opacbonusclaims:common_claim", 1, "Bonus Claim +1", "Adds 1 claim chunk.", false));
        add(items, new ShopEntry("uncommon", "opacbonusclaims:uncommon_claim", 3, "Bonus Claim +3", "Adds 3 claim chunks.", false));
        add(items, new ShopEntry("rare", "opacbonusclaims:rare_claim", 5, "Bonus Claim +5", "Adds 5 claim chunks.", false));
        add(items, new ShopEntry("epic", "opacbonusclaims:epic_claim", 9, "Bonus Claim +10", "Adds 10 claim chunks. Bulk discount applied.", false));
        add(items, new ShopEntry("fcommon", "opacbonusclaims:common_forceload", 10, "Bonus Forceload +1", "Adds 1 forceload chunk.", true));
        add(items, new ShopEntry("funcommon", "opacbonusclaims:uncommon_forceload", 15, "Bonus Forceload +3", "Adds 3 forceload chunks.", true));
        add(items, new ShopEntry("frare", "opacbonusclaims:rare_forceload", 25, "Bonus Forceload +5", "Adds 5 forceload chunks.", true));
        add(items, new ShopEntry("fepic", "opacbonusclaims:epic_forceload", 45, "Bonus Forceload +10", "Adds 10 forceload chunks. Bulk discount applied.", true));
        return items;
    }

    private static void add(Map<String, ShopEntry> items, ShopEntry entry) {
        items.put(entry.tierKey(), entry);
    }

    private static void sendError(ServerPlayer player, String text) {
        player.sendSystemMessage(Component.literal(TITLE + text).withStyle(ChatFormatting.RED));
    }

    private static void sendSuccess(ServerPlayer player, String text) {
        player.sendSystemMessage(Component.literal(TITLE + text).withStyle(ChatFormatting.GREEN));
    }

    public record ShopEntry(
            String tierKey,
            String itemId,
            int price,
            String displayName,
            String description,
            boolean forceload) {
    }
}
