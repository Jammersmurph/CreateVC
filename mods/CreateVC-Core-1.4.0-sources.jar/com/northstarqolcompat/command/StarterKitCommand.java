package com.northstarqolcompat.command;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.northstarqolcompat.network.CreateVCUiPackets;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@EventBusSubscriber(modid = NorthstarQOLCompat.MODID, bus = EventBusSubscriber.Bus.GAME)
public final class StarterKitCommand {

    private static final String TITLE = "[CreateVC Starter Kit] ";
    private static final String COOLDOWN_TAG = "CreateVCStarterKitNextAllowed";
    private static final long COOLDOWN_SECONDS = 7L * 24L * 60L * 60L;
    private static final ResourceLocation SPUR_ID = ResourceLocation.parse("numismatics:spur");
    private static final Set<UUID> ACTIVE_PURCHASES = ConcurrentHashMap.newKeySet();

    private static final List<KitEntry> KIT_CONTENTS = List.of(
            new KitEntry("minecraft:iron_helmet", 1, "Iron Helmet"),
            new KitEntry("minecraft:iron_chestplate", 1, "Iron Chestplate"),
            new KitEntry("minecraft:iron_leggings", 1, "Iron Leggings"),
            new KitEntry("minecraft:iron_boots", 1, "Iron Boots"),
            new KitEntry("minecraft:iron_pickaxe", 1, "Iron Pickaxe"),
            new KitEntry("minecraft:iron_axe", 1, "Iron Axe"),
            new KitEntry("minecraft:iron_shovel", 1, "Iron Shovel"),
            new KitEntry("minecraft:iron_sword", 1, "Iron Sword"),
            new KitEntry("minecraft:shield", 1, "Shield"),
            new KitEntry("create:wrench", 1, "Wrench"),
            new KitEntry("create:goggles", 1, "Engineer Goggles"),
            new KitEntry("minecraft:cooked_beef", 32, "Cooked Beef x32"),
            new KitEntry("minecraft:bread", 16, "Bread x16"),
            new KitEntry("minecraft:torch", 64, "Torches x64"),
            new KitEntry("minecraft:crafting_table", 1, "Crafting Table"),
            new KitEntry("minecraft:furnace", 1, "Furnace"),
            new KitEntry("minecraft:chest", 2, "Chest x2"),
            new KitEntry("minecraft:red_bed", 1, "Bed"),
            new KitEntry("minecraft:water_bucket", 1, "Water Bucket"),
            new KitEntry("minecraft:coal", 16, "Coal x16")
    );

    private StarterKitCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("starterkit")
                        .requires(source -> source.getEntity() instanceof ServerPlayer)
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            openMenu(player);
                            return 1;
                        })
                        .then(Commands.literal("buy")
                                .executes(ctx -> {
                                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                                    return buyStarterKit(player);
                                }))
        );
    }

    public static int buyStarterKit(ServerPlayer player) {
        if (!ACTIVE_PURCHASES.add(player.getUUID())) {
            sendError(player, "Purchase already being processed. Try again in a moment.");
            openMenu(player);
            return 0;
        }

        try {
            long remaining = getRemainingCooldownSeconds(player);
            if (remaining > 0L) {
                sendError(player, "You can only buy this once per week. Try again in " + formatDuration(remaining) + ".");
                openMenu(player);
                return 0;
            }

            int currentSpurs = countSpurs(player);
            if (currentSpurs < 10) {
                sendError(player, "You need 10 spurs, but only have " + currentSpurs + ".");
                openMenu(player);
                return 0;
            }

            if (!removeSpurs(player, 10)) {
                sendError(player, "Purchase failed while deducting spurs. Try again.");
                openMenu(player);
                return 0;
            }

            setNextAllowedTimestamp(player, currentUnixSeconds() + COOLDOWN_SECONDS);
            giveKit(player);

            sendSuccess(player, "Purchased starter kit for 10 spurs.");
            player.sendSystemMessage(Component.literal("You can buy another starter kit in 7 days.").withStyle(ChatFormatting.GRAY));
            player.sendSystemMessage(Component.literal("Remaining spurs: " + countSpurs(player)).withStyle(ChatFormatting.YELLOW));
            openMenu(player);
            return 1;
        } finally {
            ACTIVE_PURCHASES.remove(player.getUUID());
        }
    }

    public static void openMenu(ServerPlayer player) {
        CreateVCUiPackets.openStarterKit(player);
    }

    private static void giveKit(ServerPlayer player) {
        for (KitEntry entry : KIT_CONTENTS) {
            Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(entry.itemId()));
            if (item == null || item == Items.AIR) {
                NorthstarQOLCompat.LOGGER.warn("[CreateVC-Core] Starter kit item missing: {}", entry.itemId());
                continue;
            }

            player.getInventory().placeItemBackInInventory(new ItemStack(item, entry.count()), true);
        }
        player.containerMenu.broadcastChanges();
    }

    public static int countSpurs(ServerPlayer player) {
        Item spurItem = BuiltInRegistries.ITEM.get(SPUR_ID);
        if (spurItem == null || spurItem == Items.AIR) {
            return 0;
        }
        return player.getInventory().countItem(spurItem);
    }

    private static boolean removeSpurs(ServerPlayer player, int amount) {
        Item spurItem = BuiltInRegistries.ITEM.get(SPUR_ID);
        if (spurItem == null || spurItem == Items.AIR) {
            return false;
        }

        Inventory inventory = player.getInventory();
        int remaining = amount;
        remaining = drainList(inventory.items, spurItem, remaining);
        remaining = drainList(inventory.offhand, spurItem, remaining);

        if (remaining > 0) {
            return false;
        }

        inventory.setChanged();
        player.containerMenu.broadcastChanges();
        return true;
    }

    private static int drainList(List<ItemStack> stacks, Item target, int remaining) {
        for (ItemStack stack : stacks) {
            if (remaining <= 0) {
                break;
            }
            if (!stack.is(target)) {
                continue;
            }

            int taken = Math.min(stack.getCount(), remaining);
            stack.shrink(taken);
            remaining -= taken;
        }
        return remaining;
    }

    public static long getRemainingCooldownSeconds(ServerPlayer player) {
        long nextAllowed = player.getPersistentData().getLong(COOLDOWN_TAG);
        return Math.max(0L, nextAllowed - currentUnixSeconds());
    }

    private static void setNextAllowedTimestamp(ServerPlayer player, long unixSeconds) {
        player.getPersistentData().putLong(COOLDOWN_TAG, unixSeconds);
    }

    private static long currentUnixSeconds() {
        return System.currentTimeMillis() / 1000L;
    }

    public static String formatDuration(long totalSeconds) {
        long days = totalSeconds / 86400L;
        long hours = (totalSeconds % 86400L) / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;

        StringBuilder builder = new StringBuilder();
        if (days > 0L) {
            builder.append(days).append("d ");
        }
        if (hours > 0L) {
            builder.append(hours).append("h ");
        }
        if (minutes > 0L) {
            builder.append(minutes).append("m ");
        }
        if (seconds > 0L || builder.isEmpty()) {
            builder.append(seconds).append("s");
        }

        return builder.toString().trim();
    }

    public static List<KitEntry> kitContents() {
        return KIT_CONTENTS;
    }

    private static MutableComponent title(String text) {
        return Component.literal(TITLE + text);
    }

    private static void sendError(ServerPlayer player, String text) {
        player.sendSystemMessage(title(text).withStyle(ChatFormatting.RED));
    }

    private static void sendSuccess(ServerPlayer player, String text) {
        player.sendSystemMessage(title(text).withStyle(ChatFormatting.GREEN));
    }

    public record KitEntry(String itemId, int count, String label) {}
}
