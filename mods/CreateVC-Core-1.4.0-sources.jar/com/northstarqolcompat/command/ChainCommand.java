package com.northstarqolcompat.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.northstarqolcompat.config.NorthstarQOLCompatConfig;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.ArrayList;
import java.util.List;

public class ChainCommand {

    private static final SuggestionProvider<CommandSourceStack> COMMAND_SUGGESTIONS = (context, builder) -> {
        String remaining = builder.getRemaining();
        
        if (remaining.startsWith("/")) {
            remaining = remaining.substring(1);
        }
        
        if (remaining.isEmpty()) {
            return builder.buildFuture();
        }
        
        final String remainingLower = remaining.toLowerCase();
        
        context.getSource().getServer().getCommands().getDispatcher().getRoot().getChildren().forEach(node -> {
            String name = node.getName();
            if (name.toLowerCase().startsWith(remainingLower)) {
                builder.suggest(name);
            }
        });
        
        return builder.buildFuture();
    };

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        if (!NorthstarQOLCompatConfig.enableChainCommand) {
            return;
        }
        
        event.getDispatcher().register(
            Commands.literal("chain")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("commands", StringArgumentType.greedyString())
                    .suggests(COMMAND_SUGGESTIONS)
                    .executes(ctx -> {
                        String commands = StringArgumentType.getString(ctx, "commands");
                        return executeChain(ctx.getSource(), commands);
                    })
                )
        );
    }

    private static int executeChain(CommandSourceStack source, String commands) {
        String[] segments = commands.split("&&");
        int successCount = 0;
        
        for (String segment : segments) {
            String cmd = segment.trim();
            if (cmd.isEmpty()) continue;
            
            if (cmd.startsWith("/")) {
                cmd = cmd.substring(1);
            }
            
            try {
                source.getServer().getCommands().getDispatcher().execute(cmd, source);
                successCount++;
            } catch (CommandSyntaxException e) {
                source.sendFailure(Component.literal("Command failed: " + cmd + " - " + e.getMessage()));
                break;
            } catch (Exception e) {
                source.sendFailure(Component.literal("Error: " + e.getMessage()));
                break;
            }
        }
        
        if (successCount > 0) {
            final int count = successCount;
            source.sendSuccess(() -> Component.literal("Executed " + count + " command(s)"), false);
        }
        
        return successCount;
    }
}