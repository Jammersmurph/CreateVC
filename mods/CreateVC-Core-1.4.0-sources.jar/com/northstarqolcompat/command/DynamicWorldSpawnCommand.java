package com.northstarqolcompat.command;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.northstarqolcompat.config.NorthstarQOLCompatConfig;
import com.spawn.EntityAnchorTransforms;
import com.spawn.SpawnAnchorEntityResolver;
import com.spawn.SpawnCreateCompat;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Comparator;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

public final class DynamicWorldSpawnCommand {
    private static final double STANDING_SEARCH_HORIZONTAL_RADIUS = 1.5D;
    private static final double STANDING_SEARCH_DOWNWARD_DEPTH = 2.5D;
    private static final double LOOK_TARGET_REACH = 16.0D;
    private static final double NEARBY_ANCHOR_HORIZONTAL_RADIUS = 8.0D;
    private static final double NEARBY_ANCHOR_VERTICAL_RADIUS = 4.0D;
    private static final double CURRENT_ANCHOR_REUSE_HORIZONTAL_RADIUS = 8.0D;
    private static final double CURRENT_ANCHOR_REUSE_VERTICAL_RADIUS = 6.0D;

    private DynamicWorldSpawnCommand() {
    }

    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(rootCommand("createvc_core"));
        event.getDispatcher().register(rootCommand("create_tickworks"));
        event.getDispatcher().register(rootCommand("create_control"));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> rootCommand(String literal) {
        return Commands.literal(literal)
                .then(Commands.literal("spawn")
                        .requires(source -> source.hasPermission(3))
                        .executes(context -> spawnStatus(context.getSource()))
                        .then(Commands.literal("status")
                                .executes(context -> spawnStatus(context.getSource())))
                        .then(Commands.literal("clear")
                                .executes(context -> spawnClear(context.getSource())))
                        .then(Commands.literal("refresh")
                                .executes(context -> spawnRefresh(context.getSource())))
                        .then(Commands.literal("follow")
                                .then(Commands.argument("target", EntityArgument.entity())
                                        .executes(context -> spawnFollow(
                                                context.getSource(),
                                                EntityArgument.getEntity(context, "target")))))
                        .then(Commands.literal("follow_vehicle")
                                .executes(context -> spawnFollowVehicle(context.getSource()))));
    }

    private static int spawnStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("Dynamic world spawn").withStyle(ChatFormatting.AQUA), false);
        source.sendSuccess(() -> Component.literal("Feature enabled: " + yesNo(NorthstarQOLCompatConfig.enableDynamicWorldSpawn)), false);
        NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().status(source.getServer())
                .ifPresent(component -> source.sendSuccess(() -> component, false));
        return 1;
    }

    private static int spawnClear(CommandSourceStack source) {
        boolean cleared = NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().clear(source.getServer());
        if (cleared) {
            source.sendSuccess(() -> Component.literal("Dynamic world spawn anchor cleared."), true);
            return 1;
        }

        source.sendFailure(Component.literal("No dynamic world spawn anchor is active."));
        return 0;
    }

    private static int spawnRefresh(CommandSourceStack source) {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            source.sendFailure(Component.literal("Dynamic world spawn is disabled in the server config."));
            return 0;
        }

        NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().refresh(source.getServer());
        NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().status(source.getServer())
                .ifPresent(component -> source.sendSuccess(() -> component, true));
        return 1;
    }

    private static int spawnFollow(CommandSourceStack source, Entity target)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            source.sendFailure(Component.literal("Dynamic world spawn is disabled in the server config."));
            return 0;
        }

        if (target instanceof ServerPlayer) {
            source.sendFailure(Component.literal("Use a moving ship entity, contraption entity, or vehicle entity instead of a player."));
            return 0;
        }

        ServerPlayer player = source.getPlayerOrException();
        NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().setAnchor(player, target);
        NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().status(source.getServer())
                .ifPresent(component -> source.sendSuccess(() -> component, true));
        return 1;
    }

    private static int spawnFollowVehicle(CommandSourceStack source)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        if (!NorthstarQOLCompatConfig.enableDynamicWorldSpawn) {
            source.sendFailure(Component.literal("Dynamic world spawn is disabled in the server config."));
            return 0;
        }

        ServerPlayer player = source.getPlayerOrException();
        Optional<Entity> anchorEntity = resolveAnchorEntityFromPlayerContext(player);
        if (anchorEntity.isEmpty()) {
            if (!NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().setAnchorFromCurrentPosition(player)) {
                source.sendFailure(Component.literal("No nearby vehicle, ship, contraption, or moving platform could be found from your current position."));
                return 0;
            }
        } else {
            NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().setAnchor(player, anchorEntity.get());
        }

        NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().status(source.getServer())
                .ifPresent(component -> source.sendSuccess(() -> component, true));
        return 1;
    }

    private static String yesNo(boolean value) {
        return value ? "yes" : "no";
    }

    private static Optional<Entity> resolveAnchorEntityFromPlayerContext(ServerPlayer player) {
        Entity vehicle = player.getRootVehicle();
        if (vehicle != player && isPotentialSpawnAnchor(player, vehicle)) {
            return Optional.of(SpawnAnchorEntityResolver.normalize(vehicle));
        }

        return findStandingAnchorEntity(player)
                .or(() -> findCurrentResolvedAnchorEntity(player))
                .or(() -> findLookTargetAnchorEntity(player))
                .map(SpawnAnchorEntityResolver::normalize);
    }

    private static Optional<Entity> findStandingAnchorEntity(ServerPlayer player) {
        AABB playerBox = player.getBoundingBox();
        AABB searchBox = playerBox
                .inflate(STANDING_SEARCH_HORIZONTAL_RADIUS, 0.0D, STANDING_SEARCH_HORIZONTAL_RADIUS)
                .move(0.0D, -STANDING_SEARCH_DOWNWARD_DEPTH, 0.0D);

        return player.level().getEntities(player, searchBox, entity -> isPotentialSpawnAnchor(player, entity)).stream()
                .filter(entity -> entity.getBoundingBox().maxY >= playerBox.minY - STANDING_SEARCH_DOWNWARD_DEPTH)
                .filter(entity -> intersectsHorizontally(entity.getBoundingBox(), playerBox))
                .sorted((left, right) -> Double.compare(
                        anchorCandidateScore(player, left),
                        anchorCandidateScore(player, right)))
                .findFirst();
    }

    private static Optional<Entity> findCurrentResolvedAnchorEntity(ServerPlayer player) {
        if (player.getServer() == null) {
            return Optional.empty();
        }

        return NorthstarQOLCompat.dynamicWorldSpawnRuntime().controller().resolvedAnchorView(player.getServer())
                .filter(view -> view.level() == player.serverLevel())
                .filter(view -> isNearResolvedAnchor(player, view))
                .flatMap(view -> Optional.ofNullable(view.entity()))
                .filter(entity -> isPotentialSpawnAnchor(player, entity));
    }

    private static Optional<Entity> findLookTargetAnchorEntity(ServerPlayer player) {
        Vec3 eyePosition = player.getEyePosition();
        Vec3 lookTarget = eyePosition.add(player.getLookAngle().scale(LOOK_TARGET_REACH));
        AABB searchBox = player.getBoundingBox()
                .expandTowards(player.getLookAngle().scale(LOOK_TARGET_REACH))
                .inflate(2.0D);

        EntityHitResult hitResult = ProjectileUtil.getEntityHitResult(
                player,
                eyePosition,
                lookTarget,
                searchBox,
                entity -> isPotentialSpawnAnchor(player, entity),
                LOOK_TARGET_REACH * LOOK_TARGET_REACH);
        return Optional.ofNullable(hitResult)
                .map(EntityHitResult::getEntity)
                .or(() -> findNearbyAnchorEntity(player));
    }

    private static Optional<Entity> findNearbyAnchorEntity(ServerPlayer player) {
        AABB searchBox = player.getBoundingBox().inflate(
                NEARBY_ANCHOR_HORIZONTAL_RADIUS,
                NEARBY_ANCHOR_VERTICAL_RADIUS,
                NEARBY_ANCHOR_HORIZONTAL_RADIUS);

        return player.level().getEntities(player, searchBox, entity -> isPotentialSpawnAnchor(player, entity)).stream()
                .min(Comparator.comparingDouble(entity -> anchorCandidateScore(player, entity)));
    }

    private static boolean isPotentialSpawnAnchor(ServerPlayer player, Entity entity) {
        if (entity == player || !entity.isAlive() || entity instanceof ServerPlayer) {
            return false;
        }

        if (EntityAnchorTransforms.supportsCustomTransform(entity) || SpawnCreateCompat.isCreateContraptionEntity(entity)) {
            return true;
        }

        if (!(entity instanceof LivingEntity)) {
            return true;
        }

        String entityTypeId = entity.getType().builtInRegistryHolder().key().location().toString();
        return entityTypeId.contains("ship")
                || entityTypeId.contains("physics")
                || entityTypeId.contains("contraption")
                || entityTypeId.contains("vehicle")
                || entityTypeId.contains("airship")
                || entityTypeId.contains("simulated")
                || entityTypeId.contains("aeronautics")
                || entityTypeId.contains("offroad");
    }

    private static boolean isNearResolvedAnchor(
            ServerPlayer player,
            com.spawn.DynamicWorldSpawnController.ResolvedAnchorView resolvedAnchor) {
        Vec3 playerPosition = player.position();
        Vec3 anchorPosition = resolvedAnchor.position();
        double horizontalDistanceSquared = horizontalDistanceSquared(playerPosition, anchorPosition);
        if (horizontalDistanceSquared > CURRENT_ANCHOR_REUSE_HORIZONTAL_RADIUS * CURRENT_ANCHOR_REUSE_HORIZONTAL_RADIUS) {
            return false;
        }

        return Math.abs(playerPosition.y - anchorPosition.y) <= CURRENT_ANCHOR_REUSE_VERTICAL_RADIUS;
    }

    private static double anchorCandidateScore(ServerPlayer player, Entity entity) {
        AABB playerBox = player.getBoundingBox();
        AABB entityBox = entity.getBoundingBox();
        Vec3 playerPosition = player.position();
        Vec3 entityCenter = entityBox.getCenter();
        String entityTypeId = entity.getType().builtInRegistryHolder().key().location().toString();

        double score = playerPosition.distanceToSqr(entityCenter);
        score += Math.abs(entityBox.maxY - playerBox.minY) * 2.0D;

        if (intersectsHorizontally(entityBox, playerBox)) {
            score -= 20.0D;
        }

        if (entityTypeId.contains("ship")
                || entityTypeId.contains("airship")
                || entityTypeId.contains("vehicle")
                || entityTypeId.contains("contraption")
                || entityTypeId.contains("physics")) {
            score -= 16.0D;
        }

        if (EntityAnchorTransforms.supportsCustomTransform(entity) || SpawnCreateCompat.isCreateContraptionEntity(entity)) {
            score -= 20.0D;
        }

        if (entityTypeId.contains("simulated")
                || entityTypeId.contains("aeronautics")
                || entityTypeId.contains("offroad")) {
            score -= 12.0D;
        }

        if (!(entity instanceof LivingEntity)) {
            score -= 6.0D;
        }

        return score;
    }

    private static double horizontalDistanceSquared(Vec3 left, Vec3 right) {
        double deltaX = left.x - right.x;
        double deltaZ = left.z - right.z;
        return deltaX * deltaX + deltaZ * deltaZ;
    }

    private static boolean intersectsHorizontally(AABB entityBox, AABB playerBox) {
        return entityBox.maxX >= playerBox.minX
                && entityBox.minX <= playerBox.maxX
                && entityBox.maxZ >= playerBox.minZ
                && entityBox.minZ <= playerBox.maxZ;
    }
}
