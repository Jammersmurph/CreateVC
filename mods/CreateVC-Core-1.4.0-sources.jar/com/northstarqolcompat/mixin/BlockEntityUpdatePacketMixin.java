package com.northstarqolcompat.mixin;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * BlockEntityUpdatePacketMixin
 *
 * Prevents "chunk bans" triggered by individual block entity update packets,
 * distinct from the chunk-load path covered by ChunkBanPreventionMixin.
 *
 * This path fires when a block entity calls setChanged() / sendBlockUpdated()
 * in response to a player interaction (e.g. looking at or right-clicking a block
 * that has a watching mechanic, opening a container, or a mod-triggered sync).
 *
 * The chunk ban loop via this path:
 * 1. Player approaches / looks at a specific block
 * 2. A mod triggers a block entity update â†’ ClientboundBlockEntityDataPacket.create()
 * 3. create() calls blockEntity.getUpdateTag() â†’ throws (corrupted state)
 * 4. Exception propagates through Netty â†’ player disconnected
 * 5. On reconnect, same packet sent â†’ kicked again
 *
 * The fix wraps getUpdateTag() in try-catch and returns an empty CompoundTag on
 * failure, allowing the packet to be sent without the corrupted data.
 */
@Mixin(ClientboundBlockEntityDataPacket.class)
public class BlockEntityUpdatePacketMixin {

    /**
     * Wraps BlockEntity.getUpdateTag() in a try-catch during individual block
     * entity update packet construction. If the block entity throws, we log
     * its position and return an empty tag so the packet is still deliverable.
     *
     * Note: In some MC 1.21.1 builds, ClientboundBlockEntityDataPacket.create()
     * may delegate to a BiFunction rather than calling getUpdateTag() directly.
     * If so, this redirect will silently be a no-op (defaultRequire: 0).
     * The chunk-load path in ChunkBanPreventionMixin still applies.
     */
    @Redirect(
        method = "create(Lnet/minecraft/world/level/block/entity/BlockEntity;)Lnet/minecraft/network/protocol/game/ClientboundBlockEntityDataPacket;",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/entity/BlockEntity;getUpdateTag(Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/nbt/CompoundTag;"
        )
    )
    private static CompoundTag createvc_safeUpdateGetUpdateTag(
            BlockEntity blockEntity, HolderLookup.Provider registries) {
        try {
            return blockEntity.getUpdateTag(registries);
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.error(
                "[CreateVC-Core] CHUNK-BAN PREVENTED â€” Block entity threw during update packet. " +
                "Block type: {} | Class: {} | Position: {} | Error: {}",
                blockEntity.getType(),
                blockEntity.getClass().getSimpleName(),
                blockEntity.getBlockPos(),
                e.getMessage()
            );
            return new CompoundTag();
        }
    }
}
