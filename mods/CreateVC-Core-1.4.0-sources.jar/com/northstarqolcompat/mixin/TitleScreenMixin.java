package com.northstarqolcompat.mixin;

import com.northstarqolcompat.client.title.CreateVCBackgroundRenderer;
import com.northstarqolcompat.client.title.CreateVCLogoRenderer;
import com.northstarqolcompat.client.title.CreateVCSocialButtons;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

    private static final String SERVER_ADDRESS = "createvc.playit.plus";

    protected TitleScreenMixin(Component title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void createvc_init(CallbackInfo ci) {
        removeRealmsButton();
        repositionOptionsRow();
        addPlayCreateVCButton();
        addSocialButtons();
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void createvc_renderBackground(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        CreateVCBackgroundRenderer.renderBackgroundFull(guiGraphics, this.width, this.height);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void createvc_render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        CreateVCBackgroundRenderer.renderOverlay(guiGraphics, this.width, this.height);
        CreateVCLogoRenderer.render(guiGraphics, this.width, 1.0F);
    }

    @Inject(method = "renderPanorama", at = @At("HEAD"), cancellable = true)
    private void createvc_cancelPanorama(GuiGraphics guiGraphics, float partialTick, CallbackInfo ci) {
        ci.cancel();
    }

    private void removeRealmsButton() {
        this.renderables.removeIf(w ->
            w instanceof AbstractWidget aw &&
            aw.getMessage().getString().contains("Realms")
        );
        this.children().removeIf(w ->
            w instanceof AbstractWidget aw &&
            aw.getMessage().getString().contains("Realms")
        );
    }

    private void repositionOptionsRow() {
        int optionsY = -1;
        for (var w : this.renderables) {
            if (w instanceof AbstractWidget aw &&
                    aw.getMessage().getString().equals("Options...")) {
                optionsY = aw.getY();
                break;
            }
        }
        if (optionsY > 0) {
            int maxY = height - 33;
            if (optionsY > maxY) {
                int delta = optionsY - maxY;
                for (var w : this.renderables) {
                    if (w instanceof AbstractWidget aw && aw.getY() == optionsY) {
                        aw.setY(aw.getY() - delta);
                    }
                }
            }
        }
    }

    private void addPlayCreateVCButton() {
        Minecraft mc = Minecraft.getInstance();
        addRenderableWidget(Button.builder(
                Component.literal("\u25B6  Play CreateVC"),
                btn -> ConnectScreen.startConnecting(
                    mc.screen,
                    mc,
                    ServerAddress.parseString(SERVER_ADDRESS),
                    new ServerData("CreateVC", SERVER_ADDRESS, ServerData.Type.OTHER),
                    false,
                    null
                ))
            .pos(width / 2 - 100, height / 4 + 80)
            .size(200, 20)
            .build());
    }

    private void addSocialButtons() {
        int socialX = width / 2 + 104;
        addRenderableWidget(CreateVCSocialButtons.createWebsiteButton(socialX, height / 4 + 32, width));
        addRenderableWidget(CreateVCSocialButtons.createDiscordButton(socialX, height / 4 + 56, width));
    }

}
