package com.northstarqolcompat.mixin;

import com.northstarqolcompat.client.title.CreateVCLogoRenderer;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.server.packs.resources.ReloadInstance;
import net.minecraft.util.FastColor;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import java.util.function.Consumer;

@Mixin(LoadingOverlay.class)
public class LoadingOverlayMixin {

    @Shadow @Final private Minecraft minecraft;
    @Shadow @Final private ReloadInstance reload;
    @Shadow @Final private Consumer<Optional<Throwable>> onFinish;
    @Shadow @Final private boolean fadeIn;
    @Shadow private float currentProgress;
    @Shadow private long fadeOutStart;
    @Shadow private long fadeInStart;

    @Unique private static final int PROGRESS_BAR_WIDTH = 240;
    @Unique private static final int PROGRESS_BAR_HEIGHT = 4;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void createvc_render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        ci.cancel();

        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        long now = Util.getMillis();

        if (this.fadeIn && this.fadeInStart == -1L) {
            this.fadeInStart = now;
        }

        float fadeOut = this.fadeOutStart > -1L ? (float)(now - this.fadeOutStart) / 1000.0F : -1.0F;
        float fadeIn = this.fadeInStart > -1L ? (float)(now - this.fadeInStart) / 500.0F : -1.0F;

        if (fadeOut >= 1.0F) {
            if (this.minecraft.screen != null) {
                this.minecraft.screen.render(guiGraphics, 0, 0, partialTick);
            }
        } else if (this.fadeIn && this.minecraft.screen != null && fadeIn < 1.0F) {
            this.minecraft.screen.render(guiGraphics, mouseX, mouseY, partialTick);
        }

        float alpha;
        if (fadeOut >= 0.0F) {
            alpha = 1.0F - Mth.clamp(fadeOut - 1.0F, 0.0F, 1.0F);
        } else if (this.fadeIn) {
            alpha = Mth.clamp(fadeIn, 0.15F, 1.0F);
        } else {
            alpha = 1.0F;
        }

        int bgAlpha = Mth.ceil(alpha * 255.0F);
        guiGraphics.fill(0, 0, width, height, FastColor.ARGB32.color(bgAlpha, 0, 0, 0));

        if (alpha > 0.01F) {
            CreateVCLogoRenderer.renderCentered(guiGraphics, width, height, alpha);

            float rawProgress = this.reload.getActualProgress();
            this.currentProgress = Mth.clamp(this.currentProgress * 0.95F + rawProgress * 0.050000012F, 0.0F, 1.0F);

            if (fadeOut < 1.0F) {
                float barAlpha = 1.0F - Mth.clamp(fadeOut, 0.0F, 1.0F);
                drawProgressBar(guiGraphics, width, height, barAlpha);
            }
        }

        if (fadeOut >= 2.0F) {
            this.minecraft.setOverlay(null);
        }

        if (this.fadeOutStart == -1L && this.reload.isDone() && (!this.fadeIn || fadeIn >= 2.0F)) {
            try {
                this.reload.checkExceptions();
                this.onFinish.accept(Optional.empty());
            } catch (Throwable throwable) {
                this.onFinish.accept(Optional.of(throwable));
            }
            this.fadeOutStart = now;
            if (this.minecraft.screen != null) {
                this.minecraft.screen.init(this.minecraft, width, height);
            }
        }
    }

    @Unique
    private void drawProgressBar(GuiGraphics graphics, int screenWidth, int screenHeight, float alpha) {
        int barX = (screenWidth - PROGRESS_BAR_WIDTH) / 2;
        int barY = screenHeight / 2 + 50;
        int fillWidth = Mth.ceil(PROGRESS_BAR_WIDTH * this.currentProgress);
        int color = FastColor.ARGB32.color(Mth.ceil(alpha * 255.0F), 255, 255, 255);

        graphics.fill(barX, barY, barX + PROGRESS_BAR_WIDTH, barY + PROGRESS_BAR_HEIGHT, FastColor.ARGB32.color(Mth.ceil(alpha * 80.0F), 255, 255, 255));
        graphics.fill(barX, barY, barX + fillWidth, barY + PROGRESS_BAR_HEIGHT, color);
    }
}
