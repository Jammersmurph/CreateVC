package com.northstarqolcompat.mixin;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Guards Copycats byte-part lookups against corrupted storage keys.
 *
 * Some legacy or corrupted Copycats multistate block entities can sync an
 * unexpected property name to the client. CopycatByteBlock then looks that key
 * up in its internal byte map and crashes when the entry is missing.
 *
 * We treat unknown properties as invalid data:
 * - return a harmless zero vector for geometry lookup
 * - return the default color index for tint lookup
 *
 * The server-side sanitizer removes bad keys at the source; this mixin keeps
 * distributed clients from crashing if a bad packet or stale chunk slips
 * through before the world data is repaired.
 */
@Mixin(
        targets = "com.copycatsplus.copycats.content.copycat.bytes.CopycatByteBlock",
        remap = false
)
public abstract class CopycatByteBlockMixin {

    private static final Set<String> WARNED_PROPERTIES = ConcurrentHashMap.newKeySet();

    @Inject(
            method = "getVectorFromProperty(Lnet/minecraft/world/level/block/state/BlockState;Ljava/lang/String;)Lnet/minecraft/core/Vec3i;",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private void createvc_guardInvalidByteVector(
            BlockState state,
            String property,
            CallbackInfoReturnable<Vec3i> cir
    ) {
        if (!isKnownByteProperty(property)) {
            warnInvalidProperty(property);
            cir.setReturnValue(Vec3i.ZERO);
        }
    }

    @Inject(
            method = "getColorIndex(Ljava/lang/String;)I",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private void createvc_guardInvalidByteColor(
            String property,
            CallbackInfoReturnable<Integer> cir
    ) {
        if (!isKnownByteProperty(property)) {
            warnInvalidProperty(property);
            cir.setReturnValue(0);
        }
    }

    @SuppressWarnings("unchecked")
    private static boolean isKnownByteProperty(String property) {
        if (property == null || property.isBlank()) {
            return false;
        }

        try {
            Class<?> targetClass = Class.forName("com.copycatsplus.copycats.content.copycat.bytes.CopycatByteBlock");
            Field byteMapField = targetClass.getDeclaredField("byteMap");
            byteMapField.setAccessible(true);
            Object rawMap = byteMapField.get(null);
            return rawMap instanceof Map<?, ?> map && map.containsKey(property);
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.debug(
                    "[CreateVC-Core] Failed to inspect CopycatByteBlock byte map: {}",
                    e.getMessage()
            );
            return true;
        }
    }

    private static void warnInvalidProperty(String property) {
        if (!WARNED_PROPERTIES.add(String.valueOf(property))) {
            return;
        }

        NorthstarQOLCompat.LOGGER.warn(
                "[CreateVC-Core] Ignoring invalid Copycat Byte property '{}' to prevent a client crash",
                property
        );
    }
}
