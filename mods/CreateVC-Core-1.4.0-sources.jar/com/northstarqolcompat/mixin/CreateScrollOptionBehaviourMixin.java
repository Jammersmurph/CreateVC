package com.northstarqolcompat.mixin;

import com.northstarqolcompat.NorthstarQOLCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * CreateScrollOptionBehaviourMixin
 *
 * Fixes a crash in Create 6.0.x on NeoForge 1.21.1 where a Mechanical Arm
 * (or other scroll-option block) has a stored scroll value that is out of
 * bounds for its enum. This happens when block entity NBT gets corrupted
 * or when a mod writes an invalid value.
 *
 * The crash occurs client-side every tick while a player looks at the arm:
 *   ScrollOptionBehaviour.get() -> ArrayIndexOutOfBoundsException
 *   index 100 out of bounds for length 3
 *
 * Fix: clamp the stored value to a valid index before the array lookup.
 */
@Mixin(
    targets = "com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollOptionBehaviour",
    remap = false
)
public abstract class CreateScrollOptionBehaviourMixin {

    @Inject(
        method = "get()Ljava/lang/Enum;",
        at = @At("HEAD"),
        cancellable = true,
        remap = false
    )
    private void northstarQOLCompat_clampScrollValue(CallbackInfoReturnable<Enum<?>> cir) {
        try {
            // Access the stored scroll value field via reflection
            java.lang.reflect.Field scrollField = this.getClass()
                    .getSuperclass()
                    .getDeclaredField("scrollableValue");
            scrollField.setAccessible(true);
            Object scrollable = scrollField.get(this);

            java.lang.reflect.Method getValue = scrollable.getClass()
                    .getMethod("getValue");
            int value = (int) getValue.invoke(scrollable);

            // Get the enum constants for this scroll option
            java.lang.reflect.Field optionsField = this.getClass()
                    .getDeclaredField("options");
            optionsField.setAccessible(true);
            Enum<?>[] options = (Enum<?>[]) optionsField.get(this);

            if (options == null || options.length == 0) return;

            if (value < 0 || value >= options.length) {
                NorthstarQOLCompat.LOGGER.warn(
                        "[CreateVC-Core] Clamping invalid scroll value {} to 0 (max: {})",
                        value, options.length - 1);
                // Set the value back to 0 to fix it permanently
                java.lang.reflect.Method setValue = scrollable.getClass()
                        .getMethod("setValue", int.class);
                setValue.invoke(scrollable, 0);
                cir.setReturnValue(options[0]);
            }
        } catch (Exception e) {
            // If anything goes wrong with reflection, let the original method run
            NorthstarQOLCompat.LOGGER.debug(
                    "[CreateVC-Core] ScrollOptionBehaviour fix reflection error: {}",
                    e.getMessage());
        }
    }
}
