package com.northstarqolcompat.mixin;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.simibubi.create.content.contraptions.ContraptionCollider;
import com.simibubi.create.foundation.collision.CollisionList;
import com.simibubi.create.foundation.collision.ContinuousOBBCollider;
import com.simibubi.create.foundation.collision.OrientedBB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = ContraptionCollider.class, remap = false)
public class CreateContraptionColliderCrashGuardMixin {
    private static long createvc_core$lastCollisionWarningMillis;

    @Redirect(
            method = "collideEntities",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/simibubi/create/foundation/collision/ContinuousOBBCollider;collideMany(Lcom/simibubi/create/foundation/collision/CollisionList;Lcom/simibubi/create/foundation/collision/CollisionList;Lcom/simibubi/create/foundation/collision/OrientedBB;Lnet/minecraft/world/phys/Vec3;FZ)Lcom/simibubi/create/foundation/collision/ContinuousOBBCollider$CollisionResponse;"
            )
    )
    private static ContinuousOBBCollider.CollisionResponse createvc_core$skipMalformedContraptionCollision(
            CollisionList contraptionColliders,
            CollisionList worldColliders,
            OrientedBB entityBox,
            Vec3 motion,
            float stepHeight,
            boolean stepEnabled) {
        try {
            return ContinuousOBBCollider.collideMany(
                    contraptionColliders,
                    worldColliders,
                    entityBox,
                    motion,
                    stepHeight,
                    stepEnabled);
        } catch (RuntimeException exception) {
            long now = System.currentTimeMillis();
            if (now - createvc_core$lastCollisionWarningMillis > 10_000L) {
                createvc_core$lastCollisionWarningMillis = now;
                NorthstarQOLCompat.LOGGER.warn(
                        "Create returned malformed contraption collision data. Skipping this entity collision to keep the server alive.",
                        exception);
            }
            return createvc_core$emptyCollisionResponse();
        }
    }

    private static ContinuousOBBCollider.CollisionResponse createvc_core$emptyCollisionResponse() {
        ContinuousOBBCollider.CollisionResponse response = new ContinuousOBBCollider.CollisionResponse();
        response.surfaceCollision = false;
        response.collisionResponse = Vec3.ZERO;
        response.normal = Vec3.ZERO;
        response.location = Vec3.ZERO;
        response.temporalResponse = 1.0D;
        return response;
    }
}
