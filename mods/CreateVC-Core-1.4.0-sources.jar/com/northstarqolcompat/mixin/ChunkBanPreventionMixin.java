package com.northstarqolcompat.mixin;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * ChunkBanPreventionMixin
 *
 * Prevents "chunk bans" caused by corrupted block entities whose getUpdateTag()
 * throws an exception during chunk packet serialization.
 *
 * The chunk ban loop:
 * 1. Player loads a chunk
 * 2. Server iterates block entities in that chunk to build the chunk packet
 * 3. One block entity's getUpdateTag() throws (corrupted NBT, bad mod state, etc.)
 * 4. Exception propagates through Netty â†’ player disconnected
 * 5. On reconnect, same chunk loads â†’ kicked again permanently
 *
 * This mixin intercepts the getUpdateTag() call inside BlockEntityInfo.create(),
 * wraps it in try-catch, logs the block type and coordinates (so admins can find
 * and remove the corrupted block), and substitutes an empty CompoundTag so the
 * chunk packet is still sent without the bad data.
 *
 * @see BlockEntityUpdatePacketMixin for individual block entity update packets
 */
@Mixin(targets = "net.minecraft.network.protocol.game.ClientboundLevelChunkPacketData$BlockEntityInfo")
public class ChunkBanPreventionMixin {

    /**
     * Wraps BlockEntity.getUpdateTag() in a try-catch during chunk load packet
     * construction. If the block entity throws, we log its position/type and
     * return an empty tag so the chunk can still be sent to the player.
     */
    @Redirect(
        method = "create",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/entity/BlockEntity;getUpdateTag(Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/nbt/CompoundTag;"
        )
    )
    private static CompoundTag createvc_safeChunkGetUpdateTag(
            BlockEntity blockEntity, HolderLookup.Provider registries) {
        try {
            return blockEntity.getUpdateTag(registries);
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.error(
                "[CreateVC-Core] CHUNK-BAN PREVENTED â€” Block entity threw during chunk serialization. " +
                "Players would have been permanently kicked from this area. " +
                "Block type: {} | Class: {} | Position: {} | Error: {}",
                blockEntity.getType(),
                blockEntity.getClass().getSimpleName(),
                blockEntity.getBlockPos(),
                e.getMessage()
            );
            NorthstarQOLCompat.LOGGER.error(
                "[CreateVC-Core] Stack trace for corrupted block at {}:",
                blockEntity.getBlockPos(), e
            );
            NorthstarQOLCompat.LOGGER.error(
                "[CreateVC-Core] To fix: teleport to the position above and break the block, " +
                "or use a chunk editor (e.g. NBTExplorer) to remove the block entity at that coordinate."
            );
            return new CompoundTag();
        }
    }
}
