package com.northstarqolcompat.mixin;

import com.simibubi.create.content.kinetics.fan.processing.FanProcessingType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Create reparses non-legacy fan processing ids on the server thread for item
 * entities caught in fan streams. With many loaded fans this burns noticeable
 * CPU even when the resolved type never changes.
 *
 * Cache both hits and misses so repeated fan ticks stop rebuilding
 * ResourceLocations for the same processing id.
 */
@Mixin(
        value = com.simibubi.create.content.kinetics.fan.processing.AllFanProcessingTypes.class,
        remap = false
)
public abstract class AllFanProcessingTypesMixin {

    @Unique
    private static final ConcurrentHashMap<String, FanProcessingType> createvc$parseLegacyCache =
            new ConcurrentHashMap<>();

    @Unique
    private static final Set<String> createvc$parseLegacyNullCache =
            ConcurrentHashMap.newKeySet();

    @Inject(
            method = "parseLegacy(Ljava/lang/String;)Lcom/simibubi/create/content/kinetics/fan/processing/FanProcessingType;",
            at = @At("HEAD"),
            cancellable = true
    )
    private static void createvc$useCachedLegacyParse(
            String name,
            CallbackInfoReturnable<FanProcessingType> cir
    ) {
        if (name == null || name.isBlank()) {
            return;
        }

        FanProcessingType cached = createvc$parseLegacyCache.get(name);
        if (cached != null) {
            cir.setReturnValue(cached);
            return;
        }

        if (createvc$parseLegacyNullCache.contains(name)) {
            cir.setReturnValue(null);
        }
    }

    @Inject(
            method = "parseLegacy(Ljava/lang/String;)Lcom/simibubi/create/content/kinetics/fan/processing/FanProcessingType;",
            at = @At("RETURN")
    )
    private static void createvc$cacheLegacyParseResult(
            String name,
            CallbackInfoReturnable<FanProcessingType> cir
    ) {
        if (name == null || name.isBlank()) {
            return;
        }

        FanProcessingType resolved = cir.getReturnValue();
        if (resolved != null) {
            createvc$parseLegacyCache.putIfAbsent(name, resolved);
            createvc$parseLegacyNullCache.remove(name);
        } else {
            createvc$parseLegacyNullCache.add(name);
        }
    }
}
