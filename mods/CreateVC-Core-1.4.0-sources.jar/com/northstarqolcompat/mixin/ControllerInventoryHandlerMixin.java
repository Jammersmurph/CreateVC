package com.northstarqolcompat.mixin;

import com.buuz135.functionalstorage.inventory.ControllerInventoryHandler;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fixes Functional Storage drawer controllers ignoring existing item stacks when
 * items are inserted via automation (hoppers, chutes, funnels, etc.).
 *
 * Root cause: automation iterates virtual slots 0 â†’ N and calls insertItem on the
 * first slot that reports isItemValid(). Empty drawer slots accept any item type,
 * so a new empty slot is always chosen over an occupied slot that already holds
 * the same item.
 *
 * Fix: when the target slot is empty, scan all controller slots for one that
 * already contains the same item and can still accept more. If found, redirect
 * the insertion there instead. Falls through to the original empty-slot logic if
 * no suitable existing slot exists (new item type, or all matching slots full).
 */
@Mixin(value = ControllerInventoryHandler.class, remap = false)
public abstract class ControllerInventoryHandlerMixin implements IItemHandler {

    @Inject(
        method = "insertItem",
        at = @At("HEAD"),
        cancellable = true,
        remap = false
    )
    private void prioritizeExistingStacks(
            int slot, ItemStack stack, boolean simulate,
            CallbackInfoReturnable<ItemStack> cir) {

        // Only intercept when the target slot is empty.
        // If it already has items, the normal path handles it correctly.
        if (!getStackInSlot(slot).isEmpty()) return;

        // Scan all slots for one that holds the same item and has room.
        int total = getSlots();
        for (int i = 0; i < total; i++) {
            if (i == slot) continue;
            ItemStack existing = getStackInSlot(i);
            if (existing.isEmpty()) continue;
            if (!ItemStack.isSameItemSameComponents(existing, stack)) continue;

            // Check (simulate) whether the matching slot accepts at least one item.
            // insertItem(i,...) will re-enter this mixin but the slot is non-empty
            // so it returns immediately â€” no recursion risk.
            ItemStack remainder = insertItem(i, stack, true);
            if (remainder.getCount() < stack.getCount()) {
                // Slot can take items â€” use it.
                cir.setReturnValue(insertItem(i, stack, simulate));
                return;
            }
            // Matching slot is full; keep scanning for another.
        }
        // No suitable existing slot found â€” let the original empty-slot logic run.
    }
}
