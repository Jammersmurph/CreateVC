package com.northstarqolcompat.mixin;

import com.simibubi.create.content.kinetics.RotationPropagator;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = RotationPropagator.class, remap = false)
public abstract class RotationPropagatorMutableNeighboursMixin {

    private static final Method CREATEVC_CORE$ADD_PROPAGATION_LOCATIONS = createvc_core$resolveAddPropagationLocations();

    @Redirect(
        method = "getPotentialNeighbourLocations",
        at = @At(
            value = "INVOKE",
            target = "Lcom/simibubi/create/content/kinetics/base/KineticBlockEntity;addPropagationLocations(Lcom/simibubi/create/content/kinetics/base/IRotate;Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/List;)Ljava/util/List;"
        )
    )
    private static List<?> createvc_core$forceMutablePropagationLocations(
        KineticBlockEntity kineticBlockEntity,
        IRotate rotate,
        BlockState blockState,
        List<?> locations
    ) {
        List<?> propagated = createvc_core$invokeAddPropagationLocations(kineticBlockEntity, rotate, blockState, locations);
        return propagated instanceof LinkedList<?> ? propagated : new LinkedList<>(propagated);
    }

    private static Method createvc_core$resolveAddPropagationLocations() {
        try {
            Method method = KineticBlockEntity.class.getMethod(
                "addPropagationLocations",
                IRotate.class,
                BlockState.class,
                List.class
            );
            method.setAccessible(true);
            return method;
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Failed to resolve Create propagation hook", exception);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<?> createvc_core$invokeAddPropagationLocations(
        KineticBlockEntity kineticBlockEntity,
        IRotate rotate,
        BlockState blockState,
        List<?> locations
    ) {
        try {
            return (List<?>) CREATEVC_CORE$ADD_PROPAGATION_LOCATIONS.invoke(kineticBlockEntity, rotate, blockState, locations);
        } catch (IllegalAccessException | InvocationTargetException exception) {
            throw new IllegalStateException("Failed to normalize Create propagation neighbours", exception);
        }
    }
}
