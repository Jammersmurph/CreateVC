package com.northstarqolcompat.mixin;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Commands.class)
public abstract class CommandsChainMixin {

    @Shadow @Final private CommandDispatcher<CommandSourceStack> dispatcher;

    @Unique
    private static final ThreadLocal<Boolean> CREATEVC_CORE$CHAIN_ACTIVE = ThreadLocal.withInitial(() -> false);

    @Inject(method = "performPrefixedCommand", at = @At("HEAD"), cancellable = true)
    private void createvc_core$handleCommandChain(CommandSourceStack source, String command, CallbackInfo ci) {
        if (CREATEVC_CORE$CHAIN_ACTIVE.get() || command == null || !command.contains("&&")) {
            return;
        }

        String[] segments = command.split("&&", -1);
        if (segments.length < 2) {
            return;
        }

        ci.cancel();
        CREATEVC_CORE$CHAIN_ACTIVE.set(true);
        try {
            for (String rawSegment : segments) {
                String segment = normalize(rawSegment);
                if (segment.isEmpty()) {
                    source.sendFailure(Component.literal("Cannot run an empty command in a chain."));
                    break;
                }

                try {
                    this.dispatcher.execute(segment, source);
                } catch (CommandSyntaxException syntaxException) {
                    source.sendFailure(Component.literal(syntaxException.getMessage()));
                    break;
                } catch (Exception exception) {
                    source.sendFailure(Component.literal("Command chain stopped: " + exception.getMessage()));
                    break;
                }
            }
        } finally {
            CREATEVC_CORE$CHAIN_ACTIVE.set(false);
        }
    }

    @Unique
    private static String normalize(String command) {
        String normalized = command.trim();
        while (normalized.startsWith("/")) {
            normalized = normalized.substring(1).trim();
        }
        return normalized;
    }
}
