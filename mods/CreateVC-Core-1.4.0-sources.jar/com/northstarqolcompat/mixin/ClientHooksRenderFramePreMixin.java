package com.northstarqolcompat.mixin;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.ClientHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Sable injects an extra RenderFrameEvent.Pre path that exposes a Zume client
 * crash in this pack. When that exact crash signature occurs, skip the failing
 * Zume listener for the current frame instead of killing the whole client.
 */
@Mixin(ClientHooks.class)
public abstract class ClientHooksRenderFramePreMixin {

    @Unique
    private static boolean createvc_core$warnedAboutZumeRenderCrash;

    @Redirect(
        method = "fireRenderFramePre",
        at = @At(
            value = "INVOKE",
            target = "Lnet/neoforged/bus/api/IEventBus;post(Lnet/neoforged/bus/api/Event;)Lnet/neoforged/bus/api/Event;"
        )
    )
    private static Event createvc_core$guardRenderFramePre(IEventBus bus, Event event) {
        try {
            return bus.post(event);
        } catch (Throwable throwable) {
            if (createvc_core$isZumeRenderFrameCrash(throwable)) {
                if (!createvc_core$warnedAboutZumeRenderCrash) {
                    createvc_core$warnedAboutZumeRenderCrash = true;
                    NorthstarQOLCompat.LOGGER.error(
                        "[CreateVC-Core] Suppressed a known Zume render-frame crash exposed by Sable/Aeronautics. " +
                        "The current frame will skip Zume handling instead of crashing the client.",
                        throwable
                    );
                }
                return event;
            }

            createvc_core$sneakyThrow(throwable);
            return event;
        }
    }

    @Unique
    private static boolean createvc_core$isZumeRenderFrameCrash(Throwable throwable) {
        if (!(throwable instanceof ArrayIndexOutOfBoundsException)) {
            return false;
        }

        for (StackTraceElement element : throwable.getStackTrace()) {
            String className = element.getClassName();
            if (className != null && className.startsWith("zume.")) {
                return true;
            }
        }

        return false;
    }

    @Unique
    @SuppressWarnings("unchecked")
    private static <T extends Throwable> void createvc_core$sneakyThrow(Throwable throwable) throws T {
        throw (T) throwable;
    }
}
