package com.northstarqolcompat.event;

import com.northstarqolcompat.command.ClaimShopCommand;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

final class ClaimShopScreen extends CreateVCPanelScreen {
    private final int spurs;

    ClaimShopScreen(int spurs) {
        super(Component.literal("CreateVC Claim Shop"));
        this.spurs = spurs;
    }

    @Override
    protected void init() {
        int left = panelLeft();
        int top = panelTop();
        int index = 0;
        for (ClaimShopCommand.ShopEntry entry : ClaimShopCommand.entries()) {
            int col = index % 2;
            int row = index / 2;
            int x = left + 16 + col * 146;
            int y = top + 70 + row * 24;
            this.addRenderableWidget(Button.builder(
                            Component.literal(entry.displayName() + " (" + entry.price() + ")"),
                            button -> sendAction("claimshop.buy", entry.tierKey()))
                    .bounds(x, y, 140, 20)
                    .build()).active = spurs >= entry.price();
            index++;
        }

        this.addRenderableWidget(Button.builder(Component.literal("Close"), button -> closeScreen())
                .bounds(left + 90, top + 176, 140, 20)
                .build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        int left = panelLeft();
        int top = panelTop();
        renderPanel(graphics, left, top, PANEL_WIDTH, PANEL_HEIGHT);
        drawPanelTitle(graphics, "Buy OpenPaC bonus claims and forceload scrolls with spurs.");

        graphics.drawString(this.font, "Your spurs: " + spurs, left + 12, top + 48, 0xFFF2A93B, false);
        graphics.drawString(this.font, "Claims", left + 16, top + 58, 0xFF8FD3FF, false);
        graphics.drawString(this.font, "Forceloads", left + 162, top + 58, 0xFFD2A3FF, false);

        int index = 0;
        for (ClaimShopCommand.ShopEntry entry : ClaimShopCommand.entries()) {
            int col = index % 2;
            int row = index / 2;
            int x = left + 16 + col * 146;
            int y = top + 92 + row * 24;
            graphics.drawString(this.font, entry.description(), x, y, 0xFFD7DEEA, false);
            index++;
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
