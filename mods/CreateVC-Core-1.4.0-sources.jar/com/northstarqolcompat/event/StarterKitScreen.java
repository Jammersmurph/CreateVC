package com.northstarqolcompat.event;

import com.northstarqolcompat.command.StarterKitCommand;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

final class StarterKitScreen extends CreateVCPanelScreen {
    private final int spurs;
    private final long cooldownSeconds;

    StarterKitScreen(int spurs, long cooldownSeconds) {
        super(Component.literal("CreateVC Starter Kit"));
        this.spurs = spurs;
        this.cooldownSeconds = cooldownSeconds;
    }

    @Override
    protected void init() {
        int left = panelLeft();
        int top = panelTop();
        boolean available = cooldownSeconds <= 0L;

        this.addRenderableWidget(Button.builder(
                        available ? Component.literal("Buy For 10 Spurs") : Component.literal("On Cooldown"),
                        button -> sendAction("starterkit.buy", ""))
                .bounds(left + 16, top + 176, 140, 20)
                .build()).active = available;

        this.addRenderableWidget(Button.builder(Component.literal("Close"), button -> closeScreen())
                .bounds(left + 164, top + 176, 140, 20)
                .build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        int left = panelLeft();
        int top = panelTop();
        renderPanel(graphics, left, top, PANEL_WIDTH, PANEL_HEIGHT);
        drawPanelTitle(graphics, "Starter gear, food, utility blocks, and Create essentials.");

        graphics.drawString(this.font, "Price: 10 spurs", left + 12, top + 48, 0xFFE082, false);
        graphics.drawString(this.font, "Your spurs: " + spurs, left + 12, top + 60, 0xFFF2A93B, false);
        graphics.drawString(this.font, "Cooldown: " + (cooldownSeconds > 0L
                ? StarterKitCommand.formatDuration(cooldownSeconds)
                : "available now"), left + 12, top + 72, cooldownSeconds > 0L ? 0xFFEF6B73 : 0xFF77D18A, false);

        graphics.drawString(this.font, "Included", left + 12, top + 92, 0xFF8FD3FF, false);
        int colWidth = 146;
        int row = 0;
        for (StarterKitCommand.KitEntry entry : StarterKitCommand.kitContents()) {
            int col = row / 9;
            int y = top + 106 + (row % 9) * 11;
            graphics.drawString(this.font, "\u2022 " + entry.label(), left + 12 + col * colWidth, y, 0xFFD7DEEA, false);
            row++;
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
