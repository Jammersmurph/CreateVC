package com.northstarqolcompat.event;

import com.northstarqolcompat.network.CreateVCUiPackets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

abstract class CreateVCPanelScreen extends Screen {
    protected static final int PANEL_WIDTH = 320;
    protected static final int PANEL_HEIGHT = 210;

    protected CreateVCPanelScreen(Component title) {
        super(title);
    }

    protected int panelLeft() {
        return (this.width - PANEL_WIDTH) / 2;
    }

    protected int panelTop() {
        return (this.height - PANEL_HEIGHT) / 2;
    }

    protected void renderPanel(GuiGraphics graphics, int left, int top, int width, int height) {
        graphics.fillGradient(left - 10, top - 10, left + width + 10, top + height + 10, 0xD0101118, 0xE0181C28);
        graphics.fill(left, top, left + width, top + height, 0xF0282F3D);
        graphics.fill(left, top, left + width, top + 24, 0xFF3A8DD6);
        graphics.fill(left, top + 24, left + width, top + 25, 0x80FFFFFF);
    }

    protected void drawPanelTitle(GuiGraphics graphics, String subtitle) {
        int left = panelLeft();
        int top = panelTop();
        graphics.drawString(this.font, this.title, left + 12, top + 8, 0xFFFFFF, false);
        if (!subtitle.isEmpty()) {
            graphics.drawString(this.font, subtitle, left + 12, top + 30, 0xC9D4E6, false);
        }
    }

    protected void sendAction(String actionId, String value) {
        PacketDistributor.sendToServer(new CreateVCUiPackets.UiActionPayload(actionId, value));
    }

    protected void closeScreen() {
        Minecraft.getInstance().setScreen(null);
    }
}
