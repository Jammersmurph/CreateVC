package com.northstarqolcompat.event;

import com.northstarqolcompat.NorthstarQOLCompat;
import com.northstarqolcompat.network.CreateVCUiPackets;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = NorthstarQOLCompat.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class CreateVCUiScreenController {
    private CreateVCUiScreenController() {
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            CreateVCUiPackets.consumePendingOpenRequest();
            return;
        }

        CreateVCUiPackets.consumePendingOpenRequest().ifPresent(request -> {
            switch (request.screenId()) {
                case "starterkit" -> minecraft.setScreen(new StarterKitScreen(request.spurs(), request.cooldownSeconds()));
                case "claimshop" -> minecraft.setScreen(new ClaimShopScreen(request.spurs()));
                default -> NorthstarQOLCompat.LOGGER.warn("[CreateVC UI] Unknown screen request: {}", request.screenId());
            }
        });
    }

}
