package com.northstarqolcompat.compat;

import com.simibubi.create.api.contraption.BlockMovementChecks;
import com.simibubi.create.api.contraption.BlockMovementChecks.CheckResult;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * Allows Functional Storage blocks (drawers, fluid drawers, controllers, etc.)
 * to be assembled into Create contraptions, and makes fluid drawers visible
 * to Create's contraption fluid system so Northstar can use them as rocket fuel.
 *
 * Two registrations:
 * 1. BlockMovementChecks â€” overrides c:relocation_not_supported so all
 *    functionalstorage blocks assemble with the contraption instead of
 *    being silently left behind.
 * 2. MountedFluidStorageType â€” registers a snapshot-based fluid storage
 *    handler for fluid_1/2/4 and their framed variants so Northstar's
 *    RocketContraption.getFluids() can see (and burn) the fluid they hold.
 */
public class FunctionalStorageContraptionCompat {

    /** Fluid drawer block registry names in functionalstorage namespace. */
    private static final String[] FLUID_DRAWER_BLOCKS = {
        "fluid_1", "fluid_2", "fluid_4",
        "framed_fluid_1", "framed_fluid_2", "framed_fluid_4"
    };

    public static void register() {
        // 1. Allow all functionalstorage blocks to move with contraptions.
        BlockMovementChecks.registerMovementAllowedCheck((state, level, pos) -> {
            String namespace = state.getBlock()
                    .builtInRegistryHolder()
                    .key()
                    .location()
                    .getNamespace();
            return "functionalstorage".equals(namespace)
                    ? CheckResult.SUCCESS
                    : CheckResult.PASS;
        });

        // 2. Register fluid storage type so fuel drawers are visible to Northstar.
        FunctionalStorageMountedFluidStorageType fluidType =
                new FunctionalStorageMountedFluidStorageType();
        for (String name : FLUID_DRAWER_BLOCKS) {
            Block block = BuiltInRegistries.BLOCK.get(
                    ResourceLocation.fromNamespaceAndPath("functionalstorage", name));
            if (block != null && block != Blocks.AIR) {
                MountedFluidStorageType.REGISTRY.register(block, fluidType);
            }
        }
    }
}
