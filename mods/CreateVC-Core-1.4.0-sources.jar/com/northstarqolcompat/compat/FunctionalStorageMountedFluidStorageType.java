package com.northstarqolcompat.compat;

import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Registers Functional Storage fluid drawers with Create's contraption fluid
 * storage system so Northstar's rocket fuel check can see the fluid they hold.
 */
public class FunctionalStorageMountedFluidStorageType
        extends MountedFluidStorageType<FunctionalStorageFluidMountedStorage> {

    FunctionalStorageMountedFluidStorageType() {
        super(FunctionalStorageFluidMountedStorage.CODEC);
        // Publish the instance so the CODEC lambda can reference it during decode.
        FunctionalStorageFluidMountedStorage.TYPE_REF.set(this);
    }

    @Override
    @Nullable
    public FunctionalStorageFluidMountedStorage mount(
            Level level, BlockState state, BlockPos pos, BlockEntity be) {
        return FunctionalStorageFluidMountedStorage
                .fromBlockEntity(this, level, state, pos, be);
    }
}
