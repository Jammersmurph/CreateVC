package com.northstarqolcompat.compat;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.ChunkEvent;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Repairs invalid Copycats material references that can recurse back into
 * copycat placeholder blocks and crash clients while the chunk is rendering.
 */
@EventBusSubscriber(modid = NorthstarQOLCompat.MODID, bus = EventBusSubscriber.Bus.GAME)
public final class CopycatsMaterialSanitizer {

    private static final String COPYCATS_PACKAGE = "com.copycatsplus.copycats";
    private static final String SAFE_FALLBACK_ID = "minecraft:air";
    private static final Set<String> STORAGE_COMPOUND_NAMES = Set.of("material_data");

    private static final Map<Class<?>, MethodPair> METHOD_CACHE = new ConcurrentHashMap<>();
    private static final Map<Class<?>, Set<String>> STORAGE_PROPERTY_CACHE = new ConcurrentHashMap<>();

    private CopycatsMaterialSanitizer() {}

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (!(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getChunk() instanceof LevelChunk chunk)) {
            return;
        }
        sanitizeChunk(level, chunk);
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ServerLevel level = player.serverLevel();
        ChunkPos center = player.chunkPosition();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int chunkX = center.x + dx;
                int chunkZ = center.z + dz;
                if (!level.getChunkSource().hasChunk(chunkX, chunkZ)) {
                    continue;
                }

                LevelChunk chunk = level.getChunkSource().getChunkNow(chunkX, chunkZ);
                if (chunk != null) {
                    sanitizeChunk(level, chunk);
                }
            }
        }
    }

    private static void sanitizeChunk(ServerLevel level, LevelChunk chunk) {
        int repaired = 0;
        for (BlockEntity blockEntity : new ArrayList<>(chunk.getBlockEntities().values())) {
            if (sanitizeBlockEntity(level, blockEntity)) {
                repaired++;
            }
        }

        if (repaired > 0) {
            NorthstarQOLCompat.LOGGER.warn(
                    "[CreateVC-Core] Repaired {} invalid Copycats block entit(ies) in chunk {}",
                    repaired,
                    chunk.getPos()
            );
        }
    }

    private static boolean sanitizeBlockEntity(ServerLevel level, BlockEntity blockEntity) {
        if (!blockEntity.getClass().getName().startsWith(COPYCATS_PACKAGE)) {
            return false;
        }

        try {
            MethodPair methods = resolveMethods(blockEntity);
            if (methods == null) {
                return false;
            }

            HolderLookup.Provider registries = level.registryAccess();
            CompoundTag tag = new CompoundTag();
            methods.writeSafe().invoke(blockEntity, tag, registries);

            List<String> fixes = new ArrayList<>();
            Set<String> validProperties = resolveStorageProperties(blockEntity);
            boolean changed = false;
            if (validProperties != null) {
                changed |= sanitizeInvalidStorageProperties(tag, validProperties, fixes, "block_entity");
            }
            changed |= sanitizeCompound(tag, fixes, "block_entity");
            if (!changed) {
                return false;
            }

            methods.read().invoke(blockEntity, tag, registries, false);
            blockEntity.setChanged();
            level.sendBlockUpdated(blockEntity.getBlockPos(), blockEntity.getBlockState(), blockEntity.getBlockState(), 3);

            NorthstarQOLCompat.LOGGER.warn(
                    "[CreateVC-Core] Sanitized Copycats block entity {} at {}: {}",
                    blockEntity.getType(),
                    blockEntity.getBlockPos(),
                    String.join("; ", fixes)
            );
            return true;
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.error(
                    "[CreateVC-Core] Failed to sanitize Copycats block entity {} at {}",
                    blockEntity.getType(),
                    blockEntity.getBlockPos(),
                    e
            );
            return false;
        }
    }

    private static MethodPair resolveMethods(BlockEntity blockEntity) {
        Class<?> blockEntityClass = blockEntity.getClass();
        MethodPair cached = METHOD_CACHE.get(blockEntityClass);
        if (cached != null) {
            return cached;
        }

        try {
            MethodPair methods = new MethodPair(
                    blockEntityClass.getMethod("writeSafe", CompoundTag.class, HolderLookup.Provider.class),
                    blockEntityClass.getMethod("read", CompoundTag.class, HolderLookup.Provider.class, boolean.class)
            );
            METHOD_CACHE.put(blockEntityClass, methods);
            return methods;
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.error(
                    "[CreateVC-Core] Copycats sanitizer could not initialise reflection for {}",
                    blockEntityClass.getName(),
                    e
            );
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private static Set<String> resolveStorageProperties(BlockEntity blockEntity) {
        Class<?> blockClass = blockEntity.getBlockState().getBlock().getClass();
        Set<String> cached = STORAGE_PROPERTY_CACHE.get(blockClass);
        if (cached != null) {
            return cached;
        }

        try {
            Method storagePropertiesMethod = blockClass.getMethod("storageProperties");
            Object result = storagePropertiesMethod.invoke(blockEntity.getBlockState().getBlock());
            if (!(result instanceof Set<?> rawSet)) {
                STORAGE_PROPERTY_CACHE.put(blockClass, Set.of());
                return Set.of();
            }

            Set<String> properties = new LinkedHashSet<>();
            for (Object entry : rawSet) {
                if (entry instanceof String name && !name.isBlank()) {
                    properties.add(name);
                }
            }

            Set<String> immutable = Set.copyOf(properties);
            STORAGE_PROPERTY_CACHE.put(blockClass, immutable);
            return immutable;
        } catch (NoSuchMethodException ignored) {
            STORAGE_PROPERTY_CACHE.put(blockClass, Set.of());
            return Set.of();
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.error(
                    "[CreateVC-Core] Failed to resolve Copycats storage properties for {}",
                    blockClass.getName(),
                    e
            );
            return null;
        }
    }

    private static boolean sanitizeInvalidStorageProperties(
            CompoundTag compound,
            Set<String> validProperties,
            List<String> fixes,
            String path
    ) {
        boolean changed = false;
        for (String key : new ArrayList<>(compound.getAllKeys())) {
            Tag child = compound.get(key);
            String childPath = path + "." + key;

            if (child instanceof CompoundTag childCompound) {
                if (STORAGE_COMPOUND_NAMES.contains(key)) {
                    for (String propertyKey : new ArrayList<>(childCompound.getAllKeys())) {
                        if (validProperties.contains(propertyKey)) {
                            continue;
                        }

                        Tag propertyValue = childCompound.get(propertyKey);
                        if (!(propertyValue instanceof CompoundTag)) {
                            continue;
                        }

                        childCompound.remove(propertyKey);
                        fixes.add(childPath + "." + propertyKey + ": removed invalid storage key");
                        changed = true;
                    }
                }

                changed |= sanitizeInvalidStorageProperties(childCompound, validProperties, fixes, childPath);
                continue;
            }

            if (child instanceof ListTag childList) {
                changed |= sanitizeInvalidStorageProperties(childList, validProperties, fixes, childPath);
            }
        }
        return changed;
    }

    private static boolean sanitizeInvalidStorageProperties(
            ListTag list,
            Set<String> validProperties,
            List<String> fixes,
            String path
    ) {
        boolean changed = false;
        for (int i = 0; i < list.size(); i++) {
            Tag child = list.get(i);
            if (child instanceof CompoundTag childCompound) {
                changed |= sanitizeInvalidStorageProperties(childCompound, validProperties, fixes, path + "[" + i + "]");
            } else if (child instanceof ListTag childList) {
                changed |= sanitizeInvalidStorageProperties(childList, validProperties, fixes, path + "[" + i + "]");
            }
        }
        return changed;
    }

    private static boolean sanitizeCompound(CompoundTag compound, List<String> fixes, String path) {
        boolean changed = false;

        if (compound.contains("Material", Tag.TAG_COMPOUND)) {
            changed |= sanitizeMaterialCompound(
                    compound.getCompound("Material"),
                    compound.contains("Item", Tag.TAG_COMPOUND) ? compound.getCompound("Item") : null,
                    fixes,
                    path + ".Material"
            );
        }

        if (compound.contains("material", Tag.TAG_COMPOUND)) {
            changed |= sanitizeMaterialCompound(
                    compound.getCompound("material"),
                    compound.contains("consumedItem", Tag.TAG_COMPOUND) ? compound.getCompound("consumedItem") : null,
                    fixes,
                    path + ".material"
            );
        }

        for (String key : new ArrayList<>(compound.getAllKeys())) {
            Tag child = compound.get(key);
            String childPath = path + "." + key;

            if (child instanceof CompoundTag childCompound) {
                changed |= sanitizeCompound(childCompound, fixes, childPath);
                continue;
            }

            if (child instanceof ListTag listTag) {
                changed |= sanitizeList(listTag, fixes, childPath);
            }
        }

        return changed;
    }

    private static boolean sanitizeList(ListTag list, List<String> fixes, String path) {
        boolean changed = false;
        for (int i = 0; i < list.size(); i++) {
            Tag child = list.get(i);
            if (child instanceof CompoundTag childCompound) {
                changed |= sanitizeCompound(childCompound, fixes, path + "[" + i + "]");
            } else if (child instanceof ListTag childList) {
                changed |= sanitizeList(childList, fixes, path + "[" + i + "]");
            }
        }
        return changed;
    }

    private static boolean sanitizeMaterialCompound(
            CompoundTag materialTag,
            CompoundTag itemTag,
            List<String> fixes,
            String path
    ) {
        if (!materialTag.contains("Name", Tag.TAG_STRING)) {
            return false;
        }

        String current = materialTag.getString("Name");
        if (!isRecursiveCopycatMaterial(current)) {
            return false;
        }

        String replacement = pickReplacementMaterial(itemTag);
        materialTag.putString("Name", replacement);
        materialTag.remove("Properties");

        if (itemTag != null && itemTag.contains("id", Tag.TAG_STRING) && isRecursiveCopycatMaterial(itemTag.getString("id"))) {
            itemTag.putString("id", SAFE_FALLBACK_ID);
            if (itemTag.contains("count", Tag.TAG_INT)) {
                itemTag.putInt("count", 0);
            }
        }

        fixes.add(path + ": " + current + " -> " + replacement);
        return true;
    }

    private static String pickReplacementMaterial(CompoundTag itemTag) {
        if (itemTag != null && itemTag.contains("id", Tag.TAG_STRING)) {
            String itemId = itemTag.getString("id");
            if (!itemId.isBlank() && !isRecursiveCopycatMaterial(itemId)) {
                return itemId;
            }
        }
        return SAFE_FALLBACK_ID;
    }

    private static boolean isRecursiveCopycatMaterial(String id) {
        if (id == null || id.isBlank()) {
            return false;
        }
        return id.startsWith("copycats:")
                || id.equals("create:copycat_base")
                || id.startsWith("create_connected:copycat");
    }

    private record MethodPair(Method writeSafe, Method read) {}
}
