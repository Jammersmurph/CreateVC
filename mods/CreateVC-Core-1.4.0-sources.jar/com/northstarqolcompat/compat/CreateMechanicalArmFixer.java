package com.northstarqolcompat.compat;

import com.northstarqolcompat.NorthstarQOLCompat;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.level.LevelEvent;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * CreateMechanicalArmFixer
 *
 * Permanently fixes corrupted Mechanical Arm scroll values that cause
 * ArrayIndexOutOfBoundsException crashes when players look at them.
 *
 * The corruption occurs when a scroll option value stored in NBT is out
 * of bounds for the enum it maps to (e.g. value=100 for a 3-option enum).
 *
 * This handler scans block entities in chunks as they load and corrects
 * any out-of-bounds scroll values immediately, before any player can
 * trigger a crash by looking at the arm.
 */
@EventBusSubscriber(modid = NorthstarQOLCompat.MODID, bus = EventBusSubscriber.Bus.GAME)
public class CreateMechanicalArmFixer {

    private static final String ARM_CLASS =
            "com.simibubi.create.content.kinetics.mechanicalArm.ArmBlockEntity";
    private static final String SCROLL_OPTION_CLASS =
            "com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollOptionBehaviour";
    private static final String SCROLL_VALUE_CLASS =
            "com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollValueBehaviour";

    private static Class<?> armClass;
    private static Field selectionModeField;
    private static Field valueField;
    private static Field maxField;
    private static Field minField;
    private static Field optionsField;
    private static Method setValueMethod;
    private static boolean initialised = false;
    private static boolean failed      = false;

    public static void register(IEventBus bus) {
        NorthstarQOLCompat.LOGGER.info(
                "[CreateVC-Core] CreateMechanicalArmFixer registered.");
    }

    private static boolean init() {
        if (initialised) return true;
        if (failed) return false;
        try {
            armClass = Class.forName(ARM_CLASS);

            selectionModeField = armClass.getDeclaredField("selectionMode");
            selectionModeField.setAccessible(true);

            Class<?> scrollValueClass = Class.forName(SCROLL_VALUE_CLASS);
            valueField = scrollValueClass.getDeclaredField("value");
            valueField.setAccessible(true);
            maxField = scrollValueClass.getDeclaredField("max");
            maxField.setAccessible(true);
            minField = scrollValueClass.getDeclaredField("min");
            minField.setAccessible(true);
            setValueMethod = scrollValueClass.getDeclaredMethod("setValue", int.class);
            setValueMethod.setAccessible(true);

            Class<?> scrollOptionClass = Class.forName(SCROLL_OPTION_CLASS);
            optionsField = scrollOptionClass.getDeclaredField("options");
            optionsField.setAccessible(true);

            initialised = true;
            NorthstarQOLCompat.LOGGER.info(
                    "[CreateVC-Core] MechanicalArm fixer reflection initialised.");
            return true;
        } catch (Exception e) {
            failed = true;
            NorthstarQOLCompat.LOGGER.warn(
                    "[CreateVC-Core] MechanicalArm fixer failed to initialise: {}",
                    e.getMessage());
            return false;
        }
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!init()) return;

        int fixed = 0;
        for (BlockEntity be : level.getChunk(event.getChunk().getPos().x,
                event.getChunk().getPos().z).getBlockEntities().values()) {
            if (fixArm(be)) fixed++;
        }
        if (fixed > 0) {
            NorthstarQOLCompat.LOGGER.info(
                    "[CreateVC-Core] Fixed {} corrupted Mechanical Arm(s) in chunk {}",
                    fixed, event.getChunk().getPos());
        }
    }

    @SubscribeEvent
    public static void onLevelLoad(LevelEvent.Load event) {
        // Reset reflection cache on world reload
        if (!(event.getLevel() instanceof ServerLevel)) return;
        NorthstarQOLCompat.LOGGER.info(
                "[CreateVC-Core] World loaded â€” MechanicalArm corruption scanner active.");
    }

    private static boolean fixArm(BlockEntity be) {
        if (!armClass.isInstance(be)) return false;
        try {
            Object selectionMode = selectionModeField.get(be);
            if (selectionMode == null) return false;

            Enum<?>[] options = (Enum<?>[]) optionsField.get(selectionMode);
            if (options == null || options.length == 0) return false;

            int value = (int) valueField.get(selectionMode);
            int min   = (int) minField.get(selectionMode);
            int max   = (int) maxField.get(selectionMode);

            if (value < min || value >= options.length) {
                int corrected = Math.max(min, Math.min(options.length - 1, value));
                setValueMethod.invoke(selectionMode, corrected);
                NorthstarQOLCompat.LOGGER.warn(
                        "[CreateVC-Core] Fixed Mechanical Arm at {} â€” scroll value {} -> {}",
                        be.getBlockPos(), value, corrected);
                return true;
            }
        } catch (Exception e) {
            NorthstarQOLCompat.LOGGER.debug(
                    "[CreateVC-Core] Error checking arm at {}: {}",
                    be.getBlockPos(), e.getMessage());
        }
        return false;
    }
}
