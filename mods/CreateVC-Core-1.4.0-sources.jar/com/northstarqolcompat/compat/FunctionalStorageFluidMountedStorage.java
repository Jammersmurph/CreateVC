package com.northstarqolcompat.compat;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageType;
import com.simibubi.create.api.contraption.storage.fluid.WrapperMountedFluidStorage;
import com.simibubi.create.foundation.fluid.CombinedTankWrapper;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Contraption-mounted representation of a Functional Storage fluid drawer.
 *
 * When the rocket assembles, each fluid drawer's tanks are snapshotted into
 * in-memory FluidTank instances here. Create's MountedFluidStorageWrapper
 * then exposes them to Northstar's fuel check. When the rocket lands and the
 * contraption disassembles, unmount() writes the (possibly depleted) fluid
 * back to the drawer's IFluidHandler capability.
 */
public class FunctionalStorageFluidMountedStorage
        extends WrapperMountedFluidStorage<CombinedTankWrapper> {

    /**
     * Set by FunctionalStorageMountedFluidStorageType constructor.
     * Captured lazily in the CODEC lambda so the xmap decode runs after
     * the type instance exists.
     */
    static final AtomicReference<FunctionalStorageMountedFluidStorageType> TYPE_REF =
            new AtomicReference<>();

    static final MapCodec<FunctionalStorageFluidMountedStorage> CODEC =
            RecordCodecBuilder.mapCodec(i -> i.group(
                    FluidStack.OPTIONAL_CODEC.listOf()
                            .fieldOf("tanks")
                            .forGetter(FunctionalStorageFluidMountedStorage::snapshotFluids)
            ).apply(i, FunctionalStorageFluidMountedStorage::fromFluids));

    /** The individual tank slots â€” needed to write back on unmount. */
    private final List<FluidTank> slots;

    private FunctionalStorageFluidMountedStorage(
            MountedFluidStorageType<?> type,
            List<FluidTank> slots) {
        super(type, buildWrapper(slots));
        this.slots = slots;
    }

    private static CombinedTankWrapper buildWrapper(List<FluidTank> slots) {
        return new CombinedTankWrapper(slots.toArray(new IFluidHandler[0]));
    }

    /** Codec decode path: reconstruct from saved fluid list. */
    private static FunctionalStorageFluidMountedStorage fromFluids(List<FluidStack> fluids) {
        List<FluidTank> tanks = new ArrayList<>(fluids.size());
        for (FluidStack fs : fluids) {
            FluidTank t = new FluidTank(Integer.MAX_VALUE);
            t.setFluid(fs.copy());
            tanks.add(t);
        }
        return new FunctionalStorageFluidMountedStorage(TYPE_REF.get(), tanks);
    }

    /** Codec encode path: snapshot current contents. */
    private List<FluidStack> snapshotFluids() {
        List<FluidStack> out = new ArrayList<>(slots.size());
        for (FluidTank t : slots) out.add(t.getFluid().copy());
        return out;
    }

    /**
     * Assembly path: snapshot the drawer's IFluidHandler into in-memory tanks.
     * Returns null if the block entity exposes no fluid capability (which
     * causes Create to skip this block's fluid registration).
     */
    @Nullable
    static FunctionalStorageFluidMountedStorage fromBlockEntity(
            MountedFluidStorageType<?> type,
            Level level, BlockState state, BlockPos pos, BlockEntity be) {

        IFluidHandler handler =
                level.getCapability(Capabilities.FluidHandler.BLOCK, pos, state, be, null);
        if (handler == null) return null;

        int count = handler.getTanks();
        List<FluidTank> tanks = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            int capacity = handler.getTankCapacity(i);
            if (capacity <= 0) capacity = Integer.MAX_VALUE;
            FluidTank t = new FluidTank(capacity);
            t.setFluid(handler.getFluidInTank(i).copy());
            tanks.add(t);
        }
        return new FunctionalStorageFluidMountedStorage(type, tanks);
    }

    /**
     * Disassembly path: write the (possibly depleted) fluid back to the
     * drawer's IFluidHandler capability so the block entity reflects what
     * was burned during the flight.
     */
    @Override
    public void unmount(Level level, BlockState state, BlockPos pos,
                        @Nullable BlockEntity be) {
        if (be == null) return;
        IFluidHandler handler =
                level.getCapability(Capabilities.FluidHandler.BLOCK, pos, state, be, null);
        if (handler == null) return;

        // Drain the existing contents of every slot first, then refill with
        // the current (post-flight) state. Per-slot drain isn't in the generic
        // IFluidHandler API, so we drain each slot using its own fluid type.
        for (int i = 0; i < handler.getTanks(); i++) {
            FluidStack existing = handler.getFluidInTank(i);
            if (!existing.isEmpty()) {
                handler.drain(existing.copy(), IFluidHandler.FluidAction.EXECUTE);
            }
        }
        for (FluidTank slot : slots) {
            FluidStack current = slot.getFluid();
            if (!current.isEmpty()) {
                handler.fill(current.copy(), IFluidHandler.FluidAction.EXECUTE);
            }
        }
    }
}
